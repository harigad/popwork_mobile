(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-confimation-confimation-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/confimation/confimation.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/confimation/confimation.page.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content class=\"scroll-content\">\n  <div class=\"confirm-code\">\n    <div class=\"confirmForm\">\n      <form (ngSubmit)=\"sendPin()\" [formGroup]=\"pinForm\">\n        <ion-input maxlength=\"1\"  class=\"pin\" type=\"text\" #a (input)=\"moveFocus(a, b)\" name=\"pin1\" formControlName=\"pin1\"></ion-input>\n        <ion-input maxlength=\"1\"  class=\"pin\" type=\"text\" #b (input)=\"moveFocus(b, c)\" name=\"pin2\" formControlName=\"pin2\"></ion-input>\n        <ion-input maxlength=\"1\"  class=\"pin\" type=\"text\" #c (input)=\"moveFocus(c, d)\" name=\"pin3\" formControlName=\"pin3\"></ion-input>\n        <ion-input maxlength=\"1\"  class=\"pin\" type=\"text\" #d name=\"pin4\" (input)=\"moveFocus(c, d, false)\" formControlName=\"pin4\"></ion-input>\n        <input type=\"submit\" style=\"position: absolute; left: -9999px; width: 1px; height: 1px;\"/>\n        <label class=\"error\" *ngIf=\"wrongPin\">Incorrect PIN number, please recheck.</label>\n      </form>\n    </div>\n  </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/confimation/confimation.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/confimation/confimation.module.ts ***!
  \*********************************************************/
/*! exports provided: ConfimationPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfimationPageModule", function() { return ConfimationPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _confimation_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./confimation.page */ "./src/app/pages/confimation/confimation.page.ts");







var routes = [
    {
        path: '',
        component: _confimation_page__WEBPACK_IMPORTED_MODULE_6__["ConfimationPage"]
    }
];
var ConfimationPageModule = /** @class */ (function () {
    function ConfimationPageModule() {
    }
    ConfimationPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes),
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"]
            ],
            declarations: [_confimation_page__WEBPACK_IMPORTED_MODULE_6__["ConfimationPage"]]
        })
    ], ConfimationPageModule);
    return ConfimationPageModule;
}());



/***/ }),

/***/ "./src/app/pages/confimation/confimation.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/pages/confimation/confimation.page.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".scroll-content {\n  text-align: center;\n}\n.scroll-content .confirm-code {\n  background: url('third-back.jpg');\n  background-size: cover;\n  height: 100%;\n  width: 100%;\n  text-align: center;\n  padding: 20px;\n}\n.scroll-content .confirm-code .confirmForm {\n  top: 45%;\n  margin: auto;\n  position: relative;\n}\nlabel {\n  color: white;\n  display: block;\n  margin: 8px;\n}\nlabel.error {\n  color: #f53d3d !important;\n}\n.pin {\n  background: #fff;\n  color: #000;\n  width: 48px;\n  display: inline-block;\n  text-align: center;\n  margin: 10px 8px;\n  border-radius: 4px;\n}\n.pin input {\n  text-align: center;\n  font-size: 22px;\n  margin: 11px 8px 11px 3px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9oYXJpL0RvY3VtZW50cy9wcm9qZWN0cy9wb3B3b3JrLWNhcGFjaXRvci9zcmMvYXBwL3BhZ2VzL2NvbmZpbWF0aW9uL2NvbmZpbWF0aW9uLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvY29uZmltYXRpb24vY29uZmltYXRpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7QUNDRjtBREFFO0VBQ0UsaUNBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0FDRUo7QURESTtFQUNFLFFBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUNHTjtBRENBO0VBQ0UsWUFBQTtFQUNBLGNBQUE7RUFDQSxXQUFBO0FDRUY7QURDQTtFQUNFLHlCQUFBO0FDRUY7QURDQTtFQUNFLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQ0VGO0FEREU7RUFDRSxrQkFBQTtFQUNBLGVBQUE7RUFDQSx5QkFBQTtBQ0dKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvY29uZmltYXRpb24vY29uZmltYXRpb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNjcm9sbC1jb250ZW50e1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIC5jb25maXJtLWNvZGV7XG4gICAgYmFja2dyb3VuZDogdXJsKCcuLi8uLi8uLi9hc3NldHMvaW1ncy90aGlyZC1iYWNrLmpwZycpO1xuICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwYWRkaW5nOiAyMHB4O1xuICAgIC5jb25maXJtRm9ybXtcbiAgICAgIHRvcDogNDUlO1xuICAgICAgbWFyZ2luOiBhdXRvO1xuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIH1cbiAgfVxufVxubGFiZWwge1xuICBjb2xvcjogd2hpdGU7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW46IDhweDtcbn1cblxubGFiZWwuZXJyb3Ige1xuICBjb2xvcjogI2Y1M2QzZCAhaW1wb3J0YW50O1xufVxuXG4ucGluIHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgY29sb3I6ICMwMDA7XG4gIHdpZHRoOiA0OHB4O1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luOiAxMHB4IDhweDtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICBpbnB1dCB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtc2l6ZTogMjJweDtcbiAgICBtYXJnaW46IDExcHggOHB4IDExcHggM3B4O1xuICB9XG59XG4iLCIuc2Nyb2xsLWNvbnRlbnQge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4uc2Nyb2xsLWNvbnRlbnQgLmNvbmZpcm0tY29kZSB7XG4gIGJhY2tncm91bmQ6IHVybChcIi4uLy4uLy4uL2Fzc2V0cy9pbWdzL3RoaXJkLWJhY2suanBnXCIpO1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICBoZWlnaHQ6IDEwMCU7XG4gIHdpZHRoOiAxMDAlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmc6IDIwcHg7XG59XG4uc2Nyb2xsLWNvbnRlbnQgLmNvbmZpcm0tY29kZSAuY29uZmlybUZvcm0ge1xuICB0b3A6IDQ1JTtcbiAgbWFyZ2luOiBhdXRvO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbmxhYmVsIHtcbiAgY29sb3I6IHdoaXRlO1xuICBkaXNwbGF5OiBibG9jaztcbiAgbWFyZ2luOiA4cHg7XG59XG5cbmxhYmVsLmVycm9yIHtcbiAgY29sb3I6ICNmNTNkM2QgIWltcG9ydGFudDtcbn1cblxuLnBpbiB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGNvbG9yOiAjMDAwO1xuICB3aWR0aDogNDhweDtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbjogMTBweCA4cHg7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbn1cbi5waW4gaW5wdXQge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogMjJweDtcbiAgbWFyZ2luOiAxMXB4IDhweCAxMXB4IDNweDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/confimation/confimation.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/confimation/confimation.page.ts ***!
  \*******************************************************/
/*! exports provided: ConfimationPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfimationPage", function() { return ConfimationPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../services/auth.service */ "./src/services/auth.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _utils_local_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../utils/local-storage */ "./src/utils/local-storage.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");







var ConfimationPage = /** @class */ (function () {
    function ConfimationPage(authService, events, fb, router, activeRoute) {
        this.authService = authService;
        this.events = events;
        this.fb = fb;
        this.router = router;
        this.activeRoute = activeRoute;
        this.wrongPin = false;
        this.sentPin = '';
    }
    ConfimationPage.prototype.ngOnInit = function () {
        var _this = this;
        this.pin1.setFocus();
        this.pinForm = this.fb.group({
            pin1: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            pin2: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            pin3: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            pin4: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
        });
        console.log(this.activeRoute.params);
        this.activeRoute.queryParams.subscribe(function (params) {
            _this.phone = params['phone'];
            _this.code = params['code'];
            _this.pinForm = _this.fb.group({
                pin1: [_this.code[0], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                pin2: [_this.code[1], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                pin3: [_this.code[2], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                pin4: [_this.code[3], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
            });
            console.log(params);
        });
    };
    ConfimationPage.prototype.sendPin = function () {
        var _this = this;
        this.wrongPin = false;
        var pin = this.pinForm.get('pin1').value + this.pinForm.get('pin2').
            value + this.pinForm.get('pin3').value + this.pinForm.get('pin4').value;
        if (pin !== this.sentPin) {
            this.sentPin = pin;
            this.authService.sendPin({ pin: pin, phone: this.phone }).subscribe(function (res) {
                Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_5__["setToLocalStorage"])('VB_USER', res);
                setTimeout(function () {
                    this.events.publish('user:loggedin');
                }.bind(_this), 300);
                _this.router.navigate(['/settings']);
            }, function (error) {
                _this.wrongPin = true;
                console.log(error);
            });
        }
    };
    ConfimationPage.prototype.moveFocus = function (currentelement, nextElement, move) {
        if (move === void 0) { move = true; }
        if (currentelement.value && move) {
            nextElement.setFocus();
        }
        if (this.pinForm.valid) {
            this.sendPin();
        }
    };
    ConfimationPage.ctorParameters = function () { return [
        { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Events"] },
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('a', { static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ConfimationPage.prototype, "pin1", void 0);
    ConfimationPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-confimation',
            template: __webpack_require__(/*! raw-loader!./confimation.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/confimation/confimation.page.html"),
            styles: [__webpack_require__(/*! ./confimation.page.scss */ "./src/app/pages/confimation/confimation.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Events"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"]])
    ], ConfimationPage);
    return ConfimationPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-confimation-confimation-module-es5.js.map