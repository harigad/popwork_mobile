(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-signup-signup-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/components/stripe-payment/stripe-payment.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/stripe-payment/stripe-payment.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"cell example example4\" id=\"example-4\">\n  <form>\n    <div id=\"example4-paymentRequest\">\n      <!--Stripe paymentRequestButton Element inserted here-->\n    </div>\n    <fieldset>\n      <legend class=\"card-only\" data-tid=\"elements_examples.form.pay_with_card\">Pay with card</legend>\n      <legend class=\"payment-request-available\" data-tid=\"elements_examples.form.enter_card_manually\">Or enter card\n        details\n      </legend>\n      <div class=\"container\">\n        <div id=\"example4-card\"></div>\n        <button type=\"submit\" data-tid=\"elements_examples.form.donate_button\">Pay</button>\n      </div>\n    </fieldset>\n    <div class=\"error\" role=\"alert\">\n      <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"17\" height=\"17\" viewBox=\"0 0 17 17\">\n        <path class=\"base\" fill=\"#000\"\n              d=\"M8.5,17 C3.80557963,17 0,13.1944204 0,8.5 C0,3.80557963 3.80557963,0 8.5,0 C13.1944204,0 17,3.80557963 17,8.5 C17,13.1944204 13.1944204,17 8.5,17 Z\"></path>\n        <path class=\"glyph\" fill=\"#FFF\"\n              d=\"M8.5,7.29791847 L6.12604076,4.92395924 C5.79409512,4.59201359 5.25590488,4.59201359 4.92395924,4.92395924 C4.59201359,5.25590488 4.59201359,5.79409512 4.92395924,6.12604076 L7.29791847,8.5 L4.92395924,10.8739592 C4.59201359,11.2059049 4.59201359,11.7440951 4.92395924,12.0760408 C5.25590488,12.4079864 5.79409512,12.4079864 6.12604076,12.0760408 L8.5,9.70208153 L10.8739592,12.0760408 C11.2059049,12.4079864 11.7440951,12.4079864 12.0760408,12.0760408 C12.4079864,11.7440951 12.4079864,11.2059049 12.0760408,10.8739592 L9.70208153,8.5 L12.0760408,6.12604076 C12.4079864,5.79409512 12.4079864,5.25590488 12.0760408,4.92395924 C11.7440951,4.59201359 11.2059049,4.59201359 10.8739592,4.92395924 L8.5,7.29791847 L8.5,7.29791847 Z\"></path>\n      </svg>\n      <span class=\"message\"></span></div>\n  </form>\n  <div class=\"success\">\n    <div class=\"icon\">\n      <svg width=\"84px\" height=\"84px\" viewBox=\"0 0 84 84\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\"\n           xmlns:xlink=\"http://www.w3.org/1999/xlink\">\n        <circle class=\"border\" cx=\"42\" cy=\"42\" r=\"40\" stroke-linecap=\"round\" stroke-width=\"4\" stroke=\"#000\"\n                fill=\"none\"></circle>\n        <path class=\"checkmark\" stroke-linecap=\"round\" stroke-linejoin=\"round\"\n              d=\"M23.375 42.5488281 36.8840688 56.0578969 64.891932 28.0500338\" stroke-width=\"4\" stroke=\"#000\"\n              fill=\"none\"></path>\n      </svg>\n    </div>\n    <h3 class=\"title\" data-tid=\"elements_examples.success.title\">Payment successful</h3>\n    <a class=\"reset\" href=\"#\">\n      <svg width=\"32px\" height=\"32px\" viewBox=\"0 0 32 32\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\"\n           xmlns:xlink=\"http://www.w3.org/1999/xlink\">\n        <path fill=\"#000000\"\n              d=\"M15,7.05492878 C10.5000495,7.55237307 7,11.3674463 7,16 C7,20.9705627 11.0294373,25 16,25 C20.9705627,25 25,20.9705627 25,16 C25,15.3627484 24.4834055,14.8461538 23.8461538,14.8461538 C23.2089022,14.8461538 22.6923077,15.3627484 22.6923077,16 C22.6923077,19.6960595 19.6960595,22.6923077 16,22.6923077 C12.3039405,22.6923077 9.30769231,19.6960595 9.30769231,16 C9.30769231,12.3039405 12.3039405,9.30769231 16,9.30769231 L16,12.0841673 C16,12.1800431 16.0275652,12.2738974 16.0794108,12.354546 C16.2287368,12.5868311 16.5380938,12.6540826 16.7703788,12.5047565 L22.3457501,8.92058924 L22.3457501,8.92058924 C22.4060014,8.88185624 22.4572275,8.83063012 22.4959605,8.7703788 C22.6452866,8.53809377 22.5780351,8.22873685 22.3457501,8.07941076 L22.3457501,8.07941076 L16.7703788,4.49524351 C16.6897301,4.44339794 16.5958758,4.41583275 16.5,4.41583275 C16.2238576,4.41583275 16,4.63969037 16,4.91583275 L16,7 L15,7 L15,7.05492878 Z M16,32 C7.163444,32 0,24.836556 0,16 C0,7.163444 7.163444,0 16,0 C24.836556,0 32,7.163444 32,16 C32,24.836556 24.836556,32 16,32 Z\"></path>\n      </svg>\n    </a>\n  </div>\n</div>\n\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/signup/signup.page.html":
/*!*************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/signup/signup.page.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n  <div class=\"signup-content\">\n    <div class=\"user-avatar\">\n      <span>[click to change photo]</span>\n      <img src=\"../../assets/imgs/noavatar.png\" alt=\"noavatar\">\n      <h3>Brian Smith</h3>\n      <p>Senior Mobile Architect,Walmart Labs</p>\n      <stripe-payment></stripe-payment>\n      <p class=\"text\">\n        Lorem ipsum dolor sit amet, consectetur adipisicing elit.\n        ipsam itaque nesciunt nihil nisi odio placeat reprehenderit\n        Atque autem dicta dolore doloremque ea fugit impedit,\n        ipsam itaque nesciunt nihil nisi odio placeat reprehenderit\n        Atque autem dolore doloremque ea fugit impedit,\n        saepe sed sunt veniam!\n      </p>\n    </div>\n  </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/components/stripe-payment/stripe-payment.ts":
/*!*************************************************************!*\
  !*** ./src/app/components/stripe-payment/stripe-payment.ts ***!
  \*************************************************************/
/*! exports provided: StripePaymentComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StripePaymentComponent", function() { return StripePaymentComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



/**
 * Generated class for the StripePaymentComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
let StripePaymentComponent = class StripePaymentComponent {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
    }
    ngOnInit() {
        const stripe = Stripe('pk_test_EQJ9zX1m5j0JkJCrIhk6FwMJ');
        // let nav = this.navCtrl;
        function registerElements(elems, exampleName) {
            const formClass = '.' + exampleName;
            const example = document.querySelector(formClass);
            const form = example.querySelector('form');
            const resetButton = example.querySelector('a.reset');
            const error = form.querySelector('.error');
            const errorMessage = error.querySelector('.message');
            function enableInputs() {
                Array.prototype.forEach.call(form.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"]'), function (input) {
                    input.removeAttribute('disabled');
                });
            }
            function disableInputs() {
                Array.prototype.forEach.call(form.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"]'), function (input) {
                    input.setAttribute('disabled', 'true');
                });
            }
            function triggerBrowserValidation() {
                // The only way to trigger HTML5 form validation UI is to fake a user submit
                // event.
                const submit = document.createElement('input');
                submit.type = 'submit';
                submit.style.display = 'none';
                form.appendChild(submit);
                submit.click();
                submit.remove();
            }
            // Listen for errors from each Element, and show error messages in the UI.
            const savedErrors = {};
            elems.forEach(function (element, idx) {
                element.on('change', function (event) {
                    if (event.error) {
                        error.classList.add('visible');
                        savedErrors[idx] = event.error.message;
                        errorMessage.innerText = event.error.message;
                    }
                    else {
                        savedErrors[idx] = null;
                        // Loop over the saved errors and find the first one, if any.
                        const nextError = Object.keys(savedErrors)
                            .sort()
                            .reduce(function (maybeFoundError, key) {
                            return maybeFoundError || savedErrors[key];
                        }, null);
                        if (nextError) {
                            // Now that they've fixed the current error, show another one.
                            errorMessage.innerText = nextError;
                        }
                        else {
                            // The user fixed the last error; no more errors.
                            error.classList.remove('visible');
                        }
                    }
                });
            });
            // Listen on the form's 'submit' handler...
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                // Trigger HTML5 validation UI on the form if any of the inputs fail
                // validation.
                let plainInputsValid = true;
                Array.prototype.forEach.call(form.querySelectorAll('input'), (input) => {
                    if (input.checkValidity && !input.checkValidity()) {
                        plainInputsValid = false;
                        return;
                    }
                });
                if (!plainInputsValid) {
                    triggerBrowserValidation();
                    return;
                }
                // Show a loading screen...
                example.classList.add('submitting');
                // Disable all inputs.
                disableInputs();
                // Gather additional customer data we may have collected in our form.
                // var name = form.querySelector('#' + exampleName + '-name');
                // var address1 = form.querySelector('#' + exampleName + '-address');
                // var city = form.querySelector('#' + exampleName + '-city');
                // var state = form.querySelector('#' + exampleName + '-state');
                // var zip = form.querySelector('#' + exampleName + '-zip');
                // var additionalData = {
                //   name: name ? name.value : undefined,
                //   address_line1: address1 ? address1.value : undefined,
                //   address_city: city ? city.value : undefined,
                //   address_state: state ? state.value : undefined,
                //   address_zip: zip ? zip.value : undefined,
                // };
                // stripe.createToken(elements[0], additionalData).then((result) => {
                //   example.classList.remove('submitting');
                //
                //   if (result.token) {
                //     example.classList.add('submitted');
                //     console.log(result);
                //     nav.push(SettingsPage);
                //   } else {
                //     enableInputs();
                //   }
                // });
            });
            resetButton.addEventListener('click', function (e) {
                e.preventDefault();
                // Resetting the form (instead of setting the value to `''` for each input)
                // helps us clear webkit autofill styles.
                form.reset();
                // Clear each Element.
                elems.forEach(function (element) {
                    element.clear();
                });
                // Reset error state as well.
                error.classList.remove('visible');
                // Resetting the form does not un-disable inputs, so we need to do it separately:
                enableInputs();
                example.classList.remove('submitted');
            });
        }
        const elements = stripe.elements({
            fonts: [
                {
                    cssSrc: 'https://rsms.me/inter/inter-ui.css'
                }
            ]
        });
        /**
         * Card Element
         */
        const card = elements.create('card', {
            style: {
                base: {
                    color: '#32325D',
                    fontWeight: 500,
                    fontFamily: 'Inter UI, Open Sans, Segoe UI, sans-serif',
                    fontSize: '16px',
                    fontSmoothing: 'antialiased',
                    '::placeholder': {
                        color: '#CFD7DF'
                    }
                },
                invalid: {
                    color: '#E25950'
                }
            }
        });
        card.mount('#example4-card');
        /**
         * Payment Request Element
         */
        const paymentRequest = stripe.paymentRequest({
            country: 'US',
            currency: 'usd',
            total: {
                amount: 20,
                label: 'Total'
            }
        });
        paymentRequest.on('token', function (result) {
            const example = document.querySelector('.example4');
            example.querySelector('.token').innerText = result.token.id;
            example.classList.add('submitted');
            result.complete('success');
        });
        const paymentRequestElement = elements.create('paymentRequestButton', {
            paymentRequest: paymentRequest,
            style: {
                paymentRequestButton: {
                    type: 'donate'
                }
            }
        });
        paymentRequest.canMakePayment().then(function (result) {
            if (result) {
                console.log(result);
                document.querySelector('.example4 .card-only').style.display = 'none';
                document.querySelector('.example4 .payment-request-available').style.display =
                    'block';
                paymentRequestElement.mount('#example4-paymentRequest');
            }
        });
        registerElements([card, paymentRequestElement], 'example4');
    }
};
StripePaymentComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] }
];
StripePaymentComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'stripe-payment',
        template: __webpack_require__(/*! raw-loader!./stripe-payment.html */ "./node_modules/raw-loader/index.js!./src/app/components/stripe-payment/stripe-payment.html")
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]])
], StripePaymentComponent);



/***/ }),

/***/ "./src/app/pages/signup/signup.module.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/signup/signup.module.ts ***!
  \***********************************************/
/*! exports provided: SignupPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignupPageModule", function() { return SignupPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _components_stripe_payment_stripe_payment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/stripe-payment/stripe-payment */ "./src/app/components/stripe-payment/stripe-payment.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _signup_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./signup.page */ "./src/app/pages/signup/signup.page.ts");








const routes = [
    {
        path: '',
        component: _signup_page__WEBPACK_IMPORTED_MODULE_7__["SignupPage"]
    }
];
let SignupPageModule = class SignupPageModule {
};
SignupPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_signup_page__WEBPACK_IMPORTED_MODULE_7__["SignupPage"], _components_stripe_payment_stripe_payment__WEBPACK_IMPORTED_MODULE_5__["StripePaymentComponent"]]
    })
], SignupPageModule);



/***/ }),

/***/ "./src/app/pages/signup/signup.page.scss":
/*!***********************************************!*\
  !*** ./src/app/pages/signup/signup.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".signup-content {\n  background: url('third-back.jpg');\n  background-size: cover;\n  height: 100%;\n  width: 100%;\n  text-align: center;\n  padding: 20px;\n}\n.signup-content .user-avatar {\n  top: 20%;\n  margin: auto;\n  position: relative;\n}\n.signup-content .user-avatar span {\n  display: block;\n  color: #fff;\n  font-weight: 100;\n}\n.signup-content .user-avatar img {\n  width: 140px;\n}\n.signup-content .user-avatar h3 {\n  margin: 0;\n  color: #fff;\n  font-weight: 100;\n  font-size: 19px;\n}\n.signup-content .user-avatar p {\n  margin-top: 0;\n  color: #fff;\n  font-size: 13px;\n  font-weight: 100;\n}\n.signup-content .user-avatar .text {\n  font-size: 12px;\n  text-align: left;\n  margin-top: 15px;\n  width: 330px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9oYXJpL0RvY3VtZW50cy9wcm9qZWN0cy9wb3B3b3JrLWNhcGFjaXRvci9zcmMvYXBwL3BhZ2VzL3NpZ251cC9zaWdudXAucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9zaWdudXAvc2lnbnVwLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBRTtFQUNFLGlDQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtBQ0NKO0FEQUk7RUFDRSxRQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FDRU47QURETTtFQUNFLGNBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7QUNHUjtBRERNO0VBQ0UsWUFBQTtBQ0dSO0FERE07RUFDRSxTQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQ0dSO0FERE07RUFDRSxhQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ0dSO0FERE07RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7QUNHUiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3NpZ251cC9zaWdudXAucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiICAuc2lnbnVwLWNvbnRlbnR7XG4gICAgYmFja2dyb3VuZDogdXJsKFwiLi4vLi4vLi4vYXNzZXRzL2ltZ3MvdGhpcmQtYmFjay5qcGdcIik7XG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHBhZGRpbmc6IDIwcHg7XG4gICAgLnVzZXItYXZhdGFye1xuICAgICAgdG9wOiAyMCU7XG4gICAgICBtYXJnaW46IGF1dG87XG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICBzcGFue1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiAxMDA7XG4gICAgICB9XG4gICAgICBpbWd7XG4gICAgICAgIHdpZHRoOiAxNDBweDtcbiAgICAgIH1cbiAgICAgIGgze1xuICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgICBmb250LXdlaWdodDogMTAwO1xuICAgICAgICBmb250LXNpemU6IDE5cHg7XG4gICAgICB9XG4gICAgICBwe1xuICAgICAgICBtYXJnaW4tdG9wOiAwO1xuICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICBmb250LXdlaWdodDogMTAwO1xuICAgICAgfVxuICAgICAgLnRleHR7XG4gICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICAgICAgbWFyZ2luLXRvcDogMTVweDtcbiAgICAgICAgd2lkdGg6IDMzMHB4O1xuICAgICAgfVxuICAgIH1cbiAgfVxuIiwiLnNpZ251cC1jb250ZW50IHtcbiAgYmFja2dyb3VuZDogdXJsKFwiLi4vLi4vLi4vYXNzZXRzL2ltZ3MvdGhpcmQtYmFjay5qcGdcIik7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDEwMCU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZzogMjBweDtcbn1cbi5zaWdudXAtY29udGVudCAudXNlci1hdmF0YXIge1xuICB0b3A6IDIwJTtcbiAgbWFyZ2luOiBhdXRvO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4uc2lnbnVwLWNvbnRlbnQgLnVzZXItYXZhdGFyIHNwYW4ge1xuICBkaXNwbGF5OiBibG9jaztcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtd2VpZ2h0OiAxMDA7XG59XG4uc2lnbnVwLWNvbnRlbnQgLnVzZXItYXZhdGFyIGltZyB7XG4gIHdpZHRoOiAxNDBweDtcbn1cbi5zaWdudXAtY29udGVudCAudXNlci1hdmF0YXIgaDMge1xuICBtYXJnaW46IDA7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXdlaWdodDogMTAwO1xuICBmb250LXNpemU6IDE5cHg7XG59XG4uc2lnbnVwLWNvbnRlbnQgLnVzZXItYXZhdGFyIHAge1xuICBtYXJnaW4tdG9wOiAwO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBmb250LXdlaWdodDogMTAwO1xufVxuLnNpZ251cC1jb250ZW50IC51c2VyLWF2YXRhciAudGV4dCB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgbWFyZ2luLXRvcDogMTVweDtcbiAgd2lkdGg6IDMzMHB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/signup/signup.page.ts":
/*!*********************************************!*\
  !*** ./src/app/pages/signup/signup.page.ts ***!
  \*********************************************/
/*! exports provided: SignupPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignupPage", function() { return SignupPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let SignupPage = class SignupPage {
    constructor() { }
    ngOnInit() {
    }
};
SignupPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-signup',
        template: __webpack_require__(/*! raw-loader!./signup.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/signup/signup.page.html"),
        styles: [__webpack_require__(/*! ./signup.page.scss */ "./src/app/pages/signup/signup.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], SignupPage);



/***/ })

}]);
//# sourceMappingURL=pages-signup-signup-module-es2015.js.map