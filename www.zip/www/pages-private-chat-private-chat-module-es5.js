(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-private-chat-private-chat-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/private-chat/private-chat.page.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/private-chat/private-chat.page.html ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <div class=\"inline arrowBack\">\n      <button (click)=\"backToMessage()\" ion-button><ion-icon name=\"arrow-back\"></ion-icon></button>\n    </div>\n    <div class=\"inline autorChat\">\n      <h4>{{ channelcreatedUser }}</h4>\n    </div>\n    <div class=\"inline arrowMore\">\n      <button ion-button><ion-icon name=\"more\"></ion-icon></button>\n    </div>\n    <div class=\"placeInfo\">\n      <span>place name, place city</span>\n    </div>\n  </ion-toolbar>\n</ion-header>\n<ion-content padding>\n  <div class=\"private-chat\" *ngFor=\"let message of messages\">\n    <div [ngClass]=\"currentUserId === message.user ? 'currentUser' : 'channelUser'\">\n      <div *ngIf=\"currentUserId !== message.user\" class=\"fromUser\">\n        <img  src=\"{{ message.fromuser_photo || './assets/imgs/no_avatar.png'}}\">\n      </div>\n      <div class=\"fromMess\">\n        <p>{{ message.message }}</p>\n      </div>\n      <div class=\"clearfix\"></div>\n    </div>\n  </div>\n</ion-content>\n<ion-footer>\n  <ion-toolbar>\n    <form class=\"messageForm\" [formGroup]=\"sendMessagePrivate\">\n      <div class=\"inputMess\">\n        <ion-input id=\"inputValue\" class=\"textMess\" placeholder=\"New Message\" formControlName=\"message\" type=\"text\"></ion-input>\n      </div>\n      <div class=\"sendMess\">\n        <button (click)=\"send(sendMessagePrivate.value)\" ion-button><ion-icon name=\"arrow-dropright-circle\"></ion-icon></button>\n      </div>\n      <div class=\"clearfix\"></div>\n    </form>\n  </ion-toolbar>\n</ion-footer>\n"

/***/ }),

/***/ "./src/app/pages/private-chat/private-chat.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/private-chat/private-chat.module.ts ***!
  \***********************************************************/
/*! exports provided: PrivateChatPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrivateChatPageModule", function() { return PrivateChatPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _private_chat_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./private-chat.page */ "./src/app/pages/private-chat/private-chat.page.ts");







var routes = [
    {
        path: '',
        component: _private_chat_page__WEBPACK_IMPORTED_MODULE_6__["PrivateChatPage"]
    }
];
var PrivateChatPageModule = /** @class */ (function () {
    function PrivateChatPageModule() {
    }
    PrivateChatPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_private_chat_page__WEBPACK_IMPORTED_MODULE_6__["PrivateChatPage"]]
        })
    ], PrivateChatPageModule);
    return PrivateChatPageModule;
}());



/***/ }),

/***/ "./src/app/pages/private-chat/private-chat.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/pages/private-chat/private-chat.page.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".clearfix {\n  clear: both;\n}\n\n.inline {\n  display: inline-block;\n  text-align: center;\n}\n\n.arrowBack {\n  width: 12%;\n}\n\n.arrowBack button {\n  background: #b9b9b9;\n  border-radius: 100%;\n  width: 32px;\n  height: 32px;\n  outline: none;\n}\n\n.arrowBack button ion-icon {\n  color: #fff;\n  font-size: 20px;\n}\n\n.autorChat {\n  width: 76%;\n}\n\n.autorChat h4 {\n  margin-bottom: 4px;\n  color: #acacac;\n  font-weight: 600;\n  text-transform: uppercase;\n}\n\n.arrowMore {\n  width: 12%;\n}\n\n.arrowMore button {\n  background: none;\n}\n\n.arrowMore button ion-icon {\n  font-size: 34px;\n  color: #9e9999;\n}\n\n.placeInfo {\n  text-align: center;\n}\n\n.placeInfo span {\n  color: #2563ef;\n  letter-spacing: 2px;\n}\n\n.fromUser {\n  width: 17%;\n  float: left;\n}\n\n.fromUser img {\n  border-radius: 100%;\n  width: 50px;\n  height: 50px;\n}\n\n.private-chat {\n  display: inline-block;\n  width: 100%;\n}\n\n.private-chat .fromMess {\n  width: 83%;\n  float: left;\n}\n\n.private-chat .fromMess p {\n  width: 230px;\n  background: #f5f5f5;\n  border-bottom-left-radius: 20px;\n  border-top-right-radius: 20px;\n  border-bottom-right-radius: 20px;\n  padding: 15px 20px;\n  margin-bottom: 0px;\n}\n\n.private-chat .currentUser {\n  float: right;\n}\n\n.private-chat .currentUser .fromMess p {\n  width: 230px;\n  background: #746bbd;\n  border-bottom-left-radius: 20px;\n  border-top-right-radius: 0;\n  border-bottom-right-radius: 20px;\n  border-top-left-radius: 20px;\n  padding: 15px 20px;\n  color: #fff;\n}\n\n.inputMess {\n  width: 80%;\n  float: left;\n}\n\n.inputMess .textMess {\n  font-size: 15px;\n}\n\n.sendMess {\n  width: 20%;\n  float: left;\n}\n\n.sendMess button {\n  background: none;\n  outline: none;\n}\n\n.sendMess button ion-icon {\n  font-size: 44px;\n  color: #3a95ff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9oYXJpL0RvY3VtZW50cy9wcm9qZWN0cy9wb3B3b3JrLWNhcGFjaXRvci9zcmMvYXBwL3BhZ2VzL3ByaXZhdGUtY2hhdC9wcml2YXRlLWNoYXQucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9wcml2YXRlLWNoYXQvcHJpdmF0ZS1jaGF0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7QUNDRjs7QURDQTtFQUNFLHFCQUFBO0VBQ0Esa0JBQUE7QUNFRjs7QURBQTtFQUNFLFVBQUE7QUNHRjs7QURGRTtFQUNFLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNJSjs7QURISTtFQUNFLFdBQUE7RUFDQSxlQUFBO0FDS047O0FEREE7RUFDRSxVQUFBO0FDSUY7O0FESEU7RUFDRSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLHlCQUFBO0FDS0o7O0FERkE7RUFDRSxVQUFBO0FDS0Y7O0FESkU7RUFDRSxnQkFBQTtBQ01KOztBRExJO0VBQ0UsZUFBQTtFQUNBLGNBQUE7QUNPTjs7QURIQTtFQUNFLGtCQUFBO0FDTUY7O0FETEU7RUFDRSxjQUFBO0VBQ0EsbUJBQUE7QUNPSjs7QURKQTtFQUNFLFVBQUE7RUFDQSxXQUFBO0FDT0Y7O0FETkU7RUFDRSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDUUo7O0FETEE7RUFDRSxxQkFBQTtFQUNBLFdBQUE7QUNRRjs7QURQRTtFQUNFLFVBQUE7RUFDQSxXQUFBO0FDU0o7O0FEUkk7RUFDRSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSwrQkFBQTtFQUNBLDZCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDVU47O0FEUEU7RUFDRSxZQUFBO0FDU0o7O0FEUE07RUFDRSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSwrQkFBQTtFQUNBLDBCQUFBO0VBQ0EsZ0NBQUE7RUFDQSw0QkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQ1NSOztBREpBO0VBQ0UsVUFBQTtFQUNBLFdBQUE7QUNPRjs7QURORTtFQUNFLGVBQUE7QUNRSjs7QURMQTtFQUNFLFVBQUE7RUFDQSxXQUFBO0FDUUY7O0FEUEU7RUFDRSxnQkFBQTtFQUNBLGFBQUE7QUNTSjs7QURSSTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FDVU4iLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9wcml2YXRlLWNoYXQvcHJpdmF0ZS1jaGF0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jbGVhcmZpeHtcbiAgY2xlYXI6IGJvdGg7XG59XG4uaW5saW5le1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5hcnJvd0JhY2t7XG4gIHdpZHRoOiAxMiU7XG4gIGJ1dHRvbntcbiAgICBiYWNrZ3JvdW5kOiAjYjliOWI5O1xuICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gICAgd2lkdGg6IDMycHg7XG4gICAgaGVpZ2h0OiAzMnB4O1xuICAgIG91dGxpbmU6IG5vbmU7XG4gICAgaW9uLWljb257XG4gICAgICBjb2xvcjogI2ZmZjtcbiAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICB9XG4gIH1cbn1cbi5hdXRvckNoYXR7XG4gIHdpZHRoOiA3NiU7XG4gIGg0e1xuICAgIG1hcmdpbi1ib3R0b206IDRweDtcbiAgICBjb2xvcjogI2FjYWNhYztcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gIH1cbn1cbi5hcnJvd01vcmV7XG4gIHdpZHRoOiAxMiU7XG4gIGJ1dHRvbntcbiAgICBiYWNrZ3JvdW5kOiBub25lO1xuICAgIGlvbi1pY29ue1xuICAgICAgZm9udC1zaXplOiAzNHB4O1xuICAgICAgY29sb3I6ICM5ZTk5OTk7XG4gICAgfVxuICB9XG59XG4ucGxhY2VJbmZve1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHNwYW57XG4gICAgY29sb3I6ICMyNTYzZWY7XG4gICAgbGV0dGVyLXNwYWNpbmc6IDJweDtcbiAgfVxufVxuLmZyb21Vc2Vye1xuICB3aWR0aDogMTclO1xuICBmbG9hdDogbGVmdDtcbiAgaW1ne1xuICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gICAgd2lkdGg6IDUwcHg7XG4gICAgaGVpZ2h0OiA1MHB4O1xuICB9XG59XG4ucHJpdmF0ZS1jaGF0e1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHdpZHRoOiAxMDAlO1xuICAuZnJvbU1lc3N7XG4gICAgd2lkdGg6IDgzJTtcbiAgICBmbG9hdDogbGVmdDtcbiAgICBwe1xuICAgICAgd2lkdGg6IDIzMHB4O1xuICAgICAgYmFja2dyb3VuZDogI2Y1ZjVmNTtcbiAgICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDIwcHg7XG4gICAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMjBweDtcbiAgICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xuICAgICAgcGFkZGluZzogMTVweCAyMHB4O1xuICAgICAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICAgIH1cbiAgfVxuICAuY3VycmVudFVzZXJ7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICAgIC5mcm9tTWVzc3tcbiAgICAgIHB7XG4gICAgICAgIHdpZHRoOiAyMzBweDtcbiAgICAgICAgYmFja2dyb3VuZDogIzc0NmJiZDtcbiAgICAgICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcbiAgICAgICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDA7XG4gICAgICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xuICAgICAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAyMHB4O1xuICAgICAgICBwYWRkaW5nOiAxNXB4IDIwcHg7XG4gICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuLmlucHV0TWVzc3tcbiAgd2lkdGg6IDgwJTtcbiAgZmxvYXQ6IGxlZnQ7XG4gIC50ZXh0TWVzc3tcbiAgICBmb250LXNpemU6IDE1cHg7XG4gIH1cbn1cbi5zZW5kTWVzc3tcbiAgd2lkdGg6IDIwJTtcbiAgZmxvYXQ6IGxlZnQ7XG4gIGJ1dHRvbntcbiAgICBiYWNrZ3JvdW5kOiBub25lO1xuICAgIG91dGxpbmU6IG5vbmU7XG4gICAgaW9uLWljb257XG4gICAgICBmb250LXNpemU6IDQ0cHg7XG4gICAgICBjb2xvcjogIzNhOTVmZjtcbiAgICB9XG4gIH1cbn1cbiIsIi5jbGVhcmZpeCB7XG4gIGNsZWFyOiBib3RoO1xufVxuXG4uaW5saW5lIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5hcnJvd0JhY2sge1xuICB3aWR0aDogMTIlO1xufVxuLmFycm93QmFjayBidXR0b24ge1xuICBiYWNrZ3JvdW5kOiAjYjliOWI5O1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICB3aWR0aDogMzJweDtcbiAgaGVpZ2h0OiAzMnB4O1xuICBvdXRsaW5lOiBub25lO1xufVxuLmFycm93QmFjayBidXR0b24gaW9uLWljb24ge1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAyMHB4O1xufVxuXG4uYXV0b3JDaGF0IHtcbiAgd2lkdGg6IDc2JTtcbn1cbi5hdXRvckNoYXQgaDQge1xuICBtYXJnaW4tYm90dG9tOiA0cHg7XG4gIGNvbG9yOiAjYWNhY2FjO1xuICBmb250LXdlaWdodDogNjAwO1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xufVxuXG4uYXJyb3dNb3JlIHtcbiAgd2lkdGg6IDEyJTtcbn1cbi5hcnJvd01vcmUgYnV0dG9uIHtcbiAgYmFja2dyb3VuZDogbm9uZTtcbn1cbi5hcnJvd01vcmUgYnV0dG9uIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAzNHB4O1xuICBjb2xvcjogIzllOTk5OTtcbn1cblxuLnBsYWNlSW5mbyB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5wbGFjZUluZm8gc3BhbiB7XG4gIGNvbG9yOiAjMjU2M2VmO1xuICBsZXR0ZXItc3BhY2luZzogMnB4O1xufVxuXG4uZnJvbVVzZXIge1xuICB3aWR0aDogMTclO1xuICBmbG9hdDogbGVmdDtcbn1cbi5mcm9tVXNlciBpbWcge1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICB3aWR0aDogNTBweDtcbiAgaGVpZ2h0OiA1MHB4O1xufVxuXG4ucHJpdmF0ZS1jaGF0IHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB3aWR0aDogMTAwJTtcbn1cbi5wcml2YXRlLWNoYXQgLmZyb21NZXNzIHtcbiAgd2lkdGg6IDgzJTtcbiAgZmxvYXQ6IGxlZnQ7XG59XG4ucHJpdmF0ZS1jaGF0IC5mcm9tTWVzcyBwIHtcbiAgd2lkdGg6IDIzMHB4O1xuICBiYWNrZ3JvdW5kOiAjZjVmNWY1O1xuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyMHB4O1xuICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMjBweDtcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDIwcHg7XG4gIHBhZGRpbmc6IDE1cHggMjBweDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xufVxuLnByaXZhdGUtY2hhdCAuY3VycmVudFVzZXIge1xuICBmbG9hdDogcmlnaHQ7XG59XG4ucHJpdmF0ZS1jaGF0IC5jdXJyZW50VXNlciAuZnJvbU1lc3MgcCB7XG4gIHdpZHRoOiAyMzBweDtcbiAgYmFja2dyb3VuZDogIzc0NmJiZDtcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcbiAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDA7XG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xuICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAyMHB4O1xuICBwYWRkaW5nOiAxNXB4IDIwcHg7XG4gIGNvbG9yOiAjZmZmO1xufVxuXG4uaW5wdXRNZXNzIHtcbiAgd2lkdGg6IDgwJTtcbiAgZmxvYXQ6IGxlZnQ7XG59XG4uaW5wdXRNZXNzIC50ZXh0TWVzcyB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbn1cblxuLnNlbmRNZXNzIHtcbiAgd2lkdGg6IDIwJTtcbiAgZmxvYXQ6IGxlZnQ7XG59XG4uc2VuZE1lc3MgYnV0dG9uIHtcbiAgYmFja2dyb3VuZDogbm9uZTtcbiAgb3V0bGluZTogbm9uZTtcbn1cbi5zZW5kTWVzcyBidXR0b24gaW9uLWljb24ge1xuICBmb250LXNpemU6IDQ0cHg7XG4gIGNvbG9yOiAjM2E5NWZmO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/private-chat/private-chat.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/private-chat/private-chat.page.ts ***!
  \*********************************************************/
/*! exports provided: PrivateChatPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrivateChatPage", function() { return PrivateChatPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../services/auth.service */ "./src/services/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _utils_local_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../utils/local-storage */ "./src/utils/local-storage.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");






var PrivateChatPage = /** @class */ (function () {
    function PrivateChatPage(authService, activeRouter, router, formBuilder) {
        this.authService = authService;
        this.activeRouter = activeRouter;
        this.router = router;
        this.formBuilder = formBuilder;
        this.sendMessagePrivate = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({});
        this.messages = [];
        this.textPrivMess = [];
        this.sendMessagePrivate = this.formBuilder.group({
            message: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
        });
    }
    PrivateChatPage.prototype.ngOnInit = function () {
        var _this = this;
        this.currentUserId = Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_4__["getFromLocalStorage"])('VB_USER').user.id;
        this.activeRouter.params.subscribe(function (params) {
            _this.channelId = params.id;
            _this.toUserId = params.id;
            _this.authService.getMessagesById(_this.channelId).subscribe(function (mess) {
                _this.channelcreatedUser = mess[0].channel_created_user;
                if (mess[0].message) {
                    _this.messages = mess;
                }
                console.log(mess);
            });
        });
    };
    PrivateChatPage.prototype.backToMessage = function () {
        this.router.navigate(['/message']).then();
    };
    PrivateChatPage.prototype.send = function (message) {
        var _this = this;
        if (this.sendMessagePrivate.valid) {
            var data = {
                user: this.currentUserId,
                message: message.message,
                channel: this.channelId,
                popwork: 0
            };
            this.authService.sendMessage(data).subscribe(function (mess) {
                _this.textPrivMess = mess;
                if (mess.insertId) {
                    _this.messages.push({
                        user: _this.currentUserId,
                        message: message.message,
                        channel: _this.channelId,
                        popwork: 0
                    });
                }
                console.log(_this.textPrivMess);
                _this.sendMessagePrivate.get('message').setValue('');
            });
        }
    };
    PrivateChatPage.ctorParameters = function () { return [
        { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"] }
    ]; };
    PrivateChatPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-private-chat',
            template: __webpack_require__(/*! raw-loader!./private-chat.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/private-chat/private-chat.page.html"),
            styles: [__webpack_require__(/*! ./private-chat.page.scss */ "./src/app/pages/private-chat/private-chat.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"]])
    ], PrivateChatPage);
    return PrivateChatPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-private-chat-private-chat-module-es5.js.map