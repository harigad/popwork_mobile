(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-home-home-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/home/home.page.html":
/*!*********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/home/home.page.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content force-overscroll=\"false\">\n  <div class=\"homepage-content\">\n    <div class=\"video-container\">\n      <div class=\"videoFixed\">\n          <gl-background-video class=\"videoBack\" src=\"/assets/video/coffee.mp4\" poster=\"/assets/imgs/home-back.png\"></gl-background-video>\n      </div>\n    </div>\n    <div class=\"numberForm\">\n      <form (submit)=\"sendPhoneNumber()\" >\n          <label style=\"text-shadow: 0px 0px 5px #fff;\">Pop<span>&#x25CF; &#x25CF; &#x25CF;</span>Work</label>\n        <input type=\"submit\" style=\"position: absolute; left: -9999px; width: 1px; height: 1px;\"/>\n      </form>\n      <button  *ngIf=\"showLoginBtn\" [disabled]=\"buttonDisabled\"  (click)=\"openSystem()\" class=\"linkendin\" ion-button>Pop In</button>\n    </div>\n    </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/home/gl-ionic-background-video/dist/esm/es5/index.js":
/*!****************************************************************************!*\
  !*** ./src/app/pages/home/gl-ionic-background-video/dist/esm/es5/index.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// GlBackgroundVideo: ES Module

/***/ }),

/***/ "./src/app/pages/home/gl-ionic-background-video/dist/esm/index.js":
/*!************************************************************************!*\
  !*** ./src/app/pages/home/gl-ionic-background-video/dist/esm/index.js ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _es5__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./es5 */ "./src/app/pages/home/gl-ionic-background-video/dist/esm/es5/index.js");
/* harmony import */ var _es5__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_es5__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _es5__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _es5__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));



/***/ }),

/***/ "./src/app/pages/home/home.module.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.module.ts ***!
  \*******************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/pages/home/home.page.ts");
/* harmony import */ var src_app_pages_home_gl_ionic_background_video__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/pages/home/gl-ionic-background-video */ "./src/app/pages/home/gl-ionic-background-video/dist/esm/index.js");
/* harmony import */ var _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../pipes/pipes.module */ "./src/pipes/pipes.module.ts");









const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]
    }
];
let HomePageModule = class HomePageModule {
};
HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes),
            _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__["PipesModule"]
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], HomePageModule);



/***/ }),

/***/ "./src/app/pages/home/home.page.scss":
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.page.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".homepage-content {\n  height: 100%;\n  width: 100%;\n  text-align: center;\n}\n.homepage-content .video-container {\n  -webkit-filter: blur(3px);\n  -moz-filter: blur(3px);\n  -o-filter: blur(3px);\n  -ms-filter: blur(3px);\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n          flex-direction: column;\n  -webkit-box-align: center;\n          align-items: center;\n}\n.homepage-content .video-container .videoFixed {\n  position: fixed;\n  top: 50%;\n  left: 30%;\n  min-width: 100%;\n  min-height: 100%;\n  width: auto;\n  height: auto;\n  -webkit-transform: translateX(-50%) translateY(-50%);\n          transform: translateX(-50%) translateY(-50%);\n}\n.homepage-content .videoBack {\n  min-width: 100%;\n  min-height: 100%;\n  position: relative;\n}\n.homepage-content .numberForm {\n  top: 70%;\n  position: relative;\n  padding: 20px;\n}\n.homepage-content label {\n  color: #fff;\n  font-size: 16px;\n  letter-spacing: 12px;\n  font-weight: 100;\n}\n.homepage-content label span {\n  letter-spacing: 2px;\n  font-size: 25px;\n  color: #efecec;\n  position: relative;\n  top: 2px;\n  margin-right: 10px;\n}\n.homepage-content .phone {\n  background: #fff;\n  color: #353535;\n  border-radius: 4px;\n  margin-top: 4px;\n}\n.homepage-content .phone input {\n  text-align: center;\n  font-size: 14px;\n  font-weight: 100;\n  letter-spacing: 2px;\n  padding: 4px 0;\n}\n.homepage-content .linkendin {\n  background: #fff;\n  width: 100%;\n  padding: 12px 0;\n  margin-top: 10px;\n  border-radius: 4px;\n  outline: none;\n  color: #ff008a;\n  font-size: 15px;\n  letter-spacing: 3px;\n  box-shadow: 0px 0px 5px #fff;\n}\n.homepage-content .modal {\n  position: absolute;\n  margin: auto;\n  left: 0;\n  right: 0;\n  width: 88%;\n  background: #fff;\n  border-radius: 4px;\n}\n.homepage-content .modal .spiner {\n  color: #ff008a;\n}\n.homepage-content .modal p {\n  margin-top: 6px;\n  margin-bottom: 0;\n  color: #ff008a;\n  letter-spacing: 2px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9oYXJpL0RvY3VtZW50cy9wcm9qZWN0cy9wb3B3b3JrLWNhcGFjaXRvci9zcmMvYXBwL3BhZ2VzL2hvbWUvaG9tZS5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2hvbWUvaG9tZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUU7RUFDRSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FDQ0o7QURBSTtFQUNFLHlCQUFBO0VBQ0Esc0JBQUE7RUFDQSxvQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUVBLG9CQUFBO0VBQUEsYUFBQTtFQUNBLDRCQUFBO0VBQUEsNkJBQUE7VUFBQSxzQkFBQTtFQUNBLHlCQUFBO1VBQUEsbUJBQUE7QUNDTjtBREFNO0VBQ0UsZUFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxvREFBQTtVQUFBLDRDQUFBO0FDRVI7QURDSTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FDQ047QURDSTtFQUNFLFFBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7QUNDTjtBRENJO0VBQ0UsV0FBQTtFQUNBLGVBQUE7RUFDQSxvQkFBQTtFQUNBLGdCQUFBO0FDQ047QURBTTtFQUNFLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxrQkFBQTtBQ0VSO0FEQ0k7RUFDRSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUNDTjtBREFNO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7QUNFUjtBRENJO0VBQ0UsZ0JBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLDRCQUFBO0FDQ047QURDTTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsVUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUNDUjtBREFRO0VBQ0UsY0FBQTtBQ0VWO0FEQVE7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7QUNFViIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2hvbWUvaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIgIC5ob21lcGFnZS1jb250ZW50IHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIC52aWRlby1jb250YWluZXJ7XG4gICAgICAtd2Via2l0LWZpbHRlcjogYmx1cigzcHgpO1xuICAgICAgLW1vei1maWx0ZXI6IGJsdXIoM3B4KTtcbiAgICAgIC1vLWZpbHRlcjogYmx1cigzcHgpO1xuICAgICAgLW1zLWZpbHRlcjogYmx1cigzcHgpO1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICAvL292ZXJmbG93OiBoaWRkZW47XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAudmlkZW9GaXhlZCB7XG4gICAgICAgIHBvc2l0aW9uOiBmaXhlZDtcbiAgICAgICAgdG9wOiA1MCU7XG4gICAgICAgIGxlZnQ6IDMwJTtcbiAgICAgICAgbWluLXdpZHRoOiAxMDAlO1xuICAgICAgICBtaW4taGVpZ2h0OiAxMDAlO1xuICAgICAgICB3aWR0aDogYXV0bztcbiAgICAgICAgaGVpZ2h0OiBhdXRvO1xuICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTUwJSkgdHJhbnNsYXRlWSgtNTAlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgLnZpZGVvQmFja3tcbiAgICAgIG1pbi13aWR0aDogMTAwJTtcbiAgICAgIG1pbi1oZWlnaHQ6IDEwMCU7XG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgfVxuICAgIC5udW1iZXJGb3Jte1xuICAgICAgdG9wOiA3MCU7XG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICBwYWRkaW5nOiAyMHB4O1xuICAgIH1cbiAgICBsYWJlbHtcbiAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgICAgbGV0dGVyLXNwYWNpbmc6IDEycHg7XG4gICAgICBmb250LXdlaWdodDogMTAwO1xuICAgICAgc3BhbntcbiAgICAgICAgbGV0dGVyLXNwYWNpbmc6IDJweDtcbiAgICAgICAgZm9udC1zaXplOiAyNXB4O1xuICAgICAgICBjb2xvcjogI2VmZWNlYztcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICB0b3A6IDJweDtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgICAgfVxuICAgIH1cbiAgICAucGhvbmUge1xuICAgICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICAgIGNvbG9yOiAjMzUzNTM1O1xuICAgICAgYm9yZGVyLXJhZGl1czogNHB4O1xuICAgICAgbWFyZ2luLXRvcDogNHB4O1xuICAgICAgaW5wdXR7XG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICBmb250LXdlaWdodDogMTAwO1xuICAgICAgICBsZXR0ZXItc3BhY2luZzogMnB4O1xuICAgICAgICBwYWRkaW5nOiA0cHggMDtcbiAgICAgIH1cbiAgICB9XG4gICAgLmxpbmtlbmRpbntcbiAgICAgIGJhY2tncm91bmQ6ICNmZmY7XG4gICAgICB3aWR0aDogMTAwJTtcbiAgICAgIHBhZGRpbmc6IDEycHggMDtcbiAgICAgIG1hcmdpbi10b3A6IDEwcHg7XG4gICAgICBib3JkZXItcmFkaXVzOiA0cHg7XG4gICAgICBvdXRsaW5lOiBub25lO1xuICAgICAgY29sb3I6ICNmZjAwOGE7XG4gICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICBsZXR0ZXItc3BhY2luZzogM3B4O1xuICAgICAgYm94LXNoYWRvdzogMHB4IDBweCA1cHggI2ZmZjtcbiAgICB9XG4gICAgICAubW9kYWx7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgbWFyZ2luOiBhdXRvO1xuICAgICAgICBsZWZ0OiAwO1xuICAgICAgICByaWdodDogMDtcbiAgICAgICAgd2lkdGg6IDg4JTtcbiAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNHB4O1xuICAgICAgICAuc3BpbmVye1xuICAgICAgICAgIGNvbG9yOiAjZmYwMDhhO1xuICAgICAgICB9XG4gICAgICAgIHB7XG4gICAgICAgICAgbWFyZ2luLXRvcDogNnB4O1xuICAgICAgICAgIG1hcmdpbi1ib3R0b206IDA7XG4gICAgICAgICAgY29sb3I6ICNmZjAwOGE7XG4gICAgICAgICAgbGV0dGVyLXNwYWNpbmc6IDJweDtcbiAgICAgICAgfVxuICAgICAgfVxuICB9XG5cblxuIiwiLmhvbWVwYWdlLWNvbnRlbnQge1xuICBoZWlnaHQ6IDEwMCU7XG4gIHdpZHRoOiAxMDAlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4uaG9tZXBhZ2UtY29udGVudCAudmlkZW8tY29udGFpbmVyIHtcbiAgLXdlYmtpdC1maWx0ZXI6IGJsdXIoM3B4KTtcbiAgLW1vei1maWx0ZXI6IGJsdXIoM3B4KTtcbiAgLW8tZmlsdGVyOiBibHVyKDNweCk7XG4gIC1tcy1maWx0ZXI6IGJsdXIoM3B4KTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLmhvbWVwYWdlLWNvbnRlbnQgLnZpZGVvLWNvbnRhaW5lciAudmlkZW9GaXhlZCB7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDMwJTtcbiAgbWluLXdpZHRoOiAxMDAlO1xuICBtaW4taGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogYXV0bztcbiAgaGVpZ2h0OiBhdXRvO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTUwJSkgdHJhbnNsYXRlWSgtNTAlKTtcbn1cbi5ob21lcGFnZS1jb250ZW50IC52aWRlb0JhY2sge1xuICBtaW4td2lkdGg6IDEwMCU7XG4gIG1pbi1oZWlnaHQ6IDEwMCU7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi5ob21lcGFnZS1jb250ZW50IC5udW1iZXJGb3JtIHtcbiAgdG9wOiA3MCU7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgcGFkZGluZzogMjBweDtcbn1cbi5ob21lcGFnZS1jb250ZW50IGxhYmVsIHtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbGV0dGVyLXNwYWNpbmc6IDEycHg7XG4gIGZvbnQtd2VpZ2h0OiAxMDA7XG59XG4uaG9tZXBhZ2UtY29udGVudCBsYWJlbCBzcGFuIHtcbiAgbGV0dGVyLXNwYWNpbmc6IDJweDtcbiAgZm9udC1zaXplOiAyNXB4O1xuICBjb2xvcjogI2VmZWNlYztcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0b3A6IDJweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuLmhvbWVwYWdlLWNvbnRlbnQgLnBob25lIHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgY29sb3I6ICMzNTM1MzU7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgbWFyZ2luLXRvcDogNHB4O1xufVxuLmhvbWVwYWdlLWNvbnRlbnQgLnBob25lIGlucHV0IHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiAxMDA7XG4gIGxldHRlci1zcGFjaW5nOiAycHg7XG4gIHBhZGRpbmc6IDRweCAwO1xufVxuLmhvbWVwYWdlLWNvbnRlbnQgLmxpbmtlbmRpbiB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nOiAxMnB4IDA7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgb3V0bGluZTogbm9uZTtcbiAgY29sb3I6ICNmZjAwOGE7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbGV0dGVyLXNwYWNpbmc6IDNweDtcbiAgYm94LXNoYWRvdzogMHB4IDBweCA1cHggI2ZmZjtcbn1cbi5ob21lcGFnZS1jb250ZW50IC5tb2RhbCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbWFyZ2luOiBhdXRvO1xuICBsZWZ0OiAwO1xuICByaWdodDogMDtcbiAgd2lkdGg6IDg4JTtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xufVxuLmhvbWVwYWdlLWNvbnRlbnQgLm1vZGFsIC5zcGluZXIge1xuICBjb2xvcjogI2ZmMDA4YTtcbn1cbi5ob21lcGFnZS1jb250ZW50IC5tb2RhbCBwIHtcbiAgbWFyZ2luLXRvcDogNnB4O1xuICBtYXJnaW4tYm90dG9tOiAwO1xuICBjb2xvcjogI2ZmMDA4YTtcbiAgbGV0dGVyLXNwYWNpbmc6IDJweDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/home/home.page.ts":
/*!*****************************************!*\
  !*** ./src/app/pages/home/home.page.ts ***!
  \*****************************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../services/auth.service */ "./src/services/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _utils_app_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../../../utils/app.config */ "./src/utils/app.config.ts");
/* harmony import */ var _utils_local_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../utils/local-storage */ "./src/utils/local-storage.ts");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");








const { Browser } = _capacitor_core__WEBPACK_IMPORTED_MODULE_7__["Plugins"];
let HomePage = class HomePage {
    constructor(navCtrl, authService, router, acvtivRoute, platform, ngZone) {
        this.navCtrl = navCtrl;
        this.authService = authService;
        this.router = router;
        this.acvtivRoute = acvtivRoute;
        this.platform = platform;
        this.ngZone = ngZone;
        this.progressStatus = '';
        this.showLoginBtn = false;
    }
    ngOnInit() {
        debugger;
        this.acvtivRoute.queryParams.subscribe(res => {
            if (res.token) {
                console.log(decodeURI(res.token));
                const tok = decodeURI(res.token);
                Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_6__["setToLocalStorage"])('VB_USER', JSON.parse(tok + '"}}'));
                this.authService.refreshToken().subscribe(res => {
                    Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_6__["setToLocalStorage"])('VB_USER', res);
                    this.router.navigate(['/main']).then();
                });
            }
            else {
                this.authService.refreshToken().subscribe(res => {
                    Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_6__["setToLocalStorage"])('VB_USER', res);
                    this.router.navigate(['/main']).then();
                });
            }
        });
        const userToken = Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_6__["getFromLocalStorage"])('VB_USER').jwt;
        if (userToken) {
            this.router.navigate(['/main']).then();
        }
        else {
            this.showLoginBtn = true;
        }
    }
    showInstall() {
        this.showProgress = true;
    }
    hideInstall() {
        this.showProgress = false;
    }
    disableButton() {
        this.buttonDisabled = true;
    }
    onChange($event) {
        this.phone = $event || '';
        if (this.phone.replace(/\D/g, '').length === 10) {
            this.sendPhoneNumber();
        }
    }
    sendPhoneNumber() {
        console.log(this.phone);
        this.authService.sendPhoneNumber({ phone: this.phone }).subscribe((res) => {
            if (res && res.status) {
                this.router.navigate(['/confimation'], { queryParams: { phone: this.phone, code: res.code } }).then();
            }
        }, (error => {
            console.log(JSON.stringify(error));
        }));
    }
    openSystem() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            window.location = _utils_app_config__WEBPACK_IMPORTED_MODULE_5__["appConfig"].loginUrl + "/linkedin/login";
            /*
                  const browser = await Browser.open(`https://popwork-dev-api.herokuapp.com/linkedin/login`, '_blank', {
                    location: 'yes',
                    zoom: 'no'
                  });
                  browser.on('loaderror').subscribe((event) => {
                    debugger;
                    if (event.url.includes('localhost')) {
                      const tok = decodeURI(event.url.replace('http://localhost:8100/?token=', ''));
                      setToLocalStorage('VB_USER', JSON.parse(tok));
                      browser.close();
                      this.ngZone.run(() => this.router.navigate(['/main'])).then();
                    }
                  });
                  browser.on('loadstop').subscribe((event) => {
                    debugger;
                    if (event.url.includes('localhost')) {
                      const tok = decodeURI(event.url.replace('http://localhost:8100/?token=', ''));
                      setToLocalStorage('VB_USER', JSON.parse(tok));
                      browser.close();
                      this.ngZone.run(() => this.router.navigate(['/main'])).then();
                    }
                  });
                  */
        });
    }
};
HomePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgZone"] }
];
HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: __webpack_require__(/*! raw-loader!./home.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/home/home.page.html"),
        styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/pages/home/home.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
        _services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgZone"]])
], HomePage);



/***/ }),

/***/ "./src/pipes/pipes-phone/pipes-phone.ts":
/*!**********************************************!*\
  !*** ./src/pipes/pipes-phone/pipes-phone.ts ***!
  \**********************************************/
/*! exports provided: PipesPhonePipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PipesPhonePipe", function() { return PipesPhonePipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let PipesPhonePipe = class PipesPhonePipe {
    /**
     * Takes a value and makes it lowercase.
     */
    transform(value = '', ...args) {
        let cleaned = ('' + value).replace(/\D/g, '');
        let match1 = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
        let match2 = cleaned.match(/^(\d{3})(\d{3})$/);
        let match3 = cleaned.match(/^(\d{3})$/);
        if (match1) {
            return '(' + match1[1] + ') ' + match1[2] + ' - ' + match1[3];
        }
        if (match2) {
            return '(' + match2[1] + ') ' + match2[2] + ' - ';
        }
        if (match3) {
            return '(' + match3[1] + ') ';
        }
        return value;
    }
};
PipesPhonePipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
        name: 'pipesPhone',
    })
], PipesPhonePipe);



/***/ }),

/***/ "./src/pipes/pipes.module.ts":
/*!***********************************!*\
  !*** ./src/pipes/pipes.module.ts ***!
  \***********************************/
/*! exports provided: PipesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PipesModule", function() { return PipesModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _pipes_phone_pipes_phone__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pipes-phone/pipes-phone */ "./src/pipes/pipes-phone/pipes-phone.ts");



let PipesModule = class PipesModule {
};
PipesModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_pipes_phone_pipes_phone__WEBPACK_IMPORTED_MODULE_2__["PipesPhonePipe"]],
        imports: [],
        exports: [_pipes_phone_pipes_phone__WEBPACK_IMPORTED_MODULE_2__["PipesPhonePipe"]]
    })
], PipesModule);



/***/ })

}]);
//# sourceMappingURL=pages-home-home-module-es2015.js.map