(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["map-map-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/components/add-channel/add-channel.component.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/add-channel/add-channel.component.html ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"new-channel\">\n  <form class=\"channelForm\" [formGroup]=\"channelForm\" (ngSubmit)=\"addChannel()\">\n    <ion-item>\n      <ion-textarea class=\"placeHolder\" #focus placeholder=\"SHOUT TO POPWORKS ON THE MAP\"\n              type=\"text\" formControlName=\"title\">\n      </ion-textarea>\n    </ion-item>\n  </form>\n</div>\n<ion-footer>\n  <ion-toolbar>\n    <div class=\"channelBtn\">\n      <button (click)=\"addChannel()\" class=\"create\" ion-button>shout</button>\n      <button (click)=\"cancel()\" class=\"cancel\" ion-button>cancel</button>\n    </div>\n  </ion-toolbar>\n</ion-footer>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/map/map.page.html":
/*!*******************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/map/map.page.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n  <div class=\"map\">\n    <div class=\"search-place\">\n      <ion-icon class=\"search-pl\" name=\"search\"></ion-icon>\n      <ion-input class=\"searchinput\" (input)=\"searchPlaces($event)\" type=\"search\" placeholder=\"find\"></ion-input>\n    </div>\n\n  </div>\n\n  <div id=\"map\" #gmap></div>\n</ion-content>\n\n<div class=\"foot\">\n  <div *ngIf=\"showPlaceInfo\" class=\"object-info\">\n      <app-place-info [place]=\"showPlaceInfo\"></app-place-info>\n</div>\n\n  <ion-range  min=\"7\" max=\"19\" step=\"0.5\"  color=\"primary\"  [(ngModel)]=\"hour\">\n    <ion-label style=\"font-size:0.7em;\" color=\"primary\" slot=\"end\" >\n    \n      <ion-datetime displayFormat=\"MM/DD/YY\" placeholder=\"Select Date\"></ion-datetime>\n\n\n    </ion-label>\n    <ion-label style=\"font-size:0.7em;\"  slot=\"start\" >7:00 AM</ion-label>\n  </ion-range>\n</div>"

/***/ }),

/***/ "./src/app/components/add-channel/add-channel.component.scss":
/*!*******************************************************************!*\
  !*** ./src/app/components/add-channel/add-channel.component.scss ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "::ng-deep .modalChannel .modal-wrapper {\n  margin: auto;\n}\n::ng-deep .modalChannel ion-backdrop {\n  opacity: 0 !important;\n}\n::ng-deep .modalChannel .new-channel {\n  margin-top: 25px;\n}\n::ng-deep .modalChannel .new-channel h4 {\n  color: #fff;\n  margin-top: 6px;\n  letter-spacing: 2px;\n  font-size: 16px;\n}\n::ng-deep .modalChannel .new-channel .channelForm ::-webkit-input-placeholder {\n  --placeholder-color: #6c8197;\n  --placeholder-opacity: 1;\n  font-size: 41px;\n  letter-spacing: 13px;\n  font-family: sans-serif;\n}\n::ng-deep .modalChannel .new-channel .channelForm ::-moz-placeholder {\n  --placeholder-color: #6c8197;\n  --placeholder-opacity: 1;\n  font-size: 41px;\n  letter-spacing: 13px;\n  font-family: sans-serif;\n}\n::ng-deep .modalChannel .new-channel .channelForm ::-ms-input-placeholder {\n  --placeholder-color: #6c8197;\n  --placeholder-opacity: 1;\n  font-size: 41px;\n  letter-spacing: 13px;\n  font-family: sans-serif;\n}\n::ng-deep .modalChannel .new-channel .channelForm ::placeholder {\n  --placeholder-color: #6c8197;\n  --placeholder-opacity: 1;\n  font-size: 41px;\n  letter-spacing: 13px;\n  font-family: sans-serif;\n}\n::ng-deep .modalChannel .new-channel .channelForm .placeHolder {\n  font-size: 28px;\n  letter-spacing: 2px;\n  font-family: sans-serif;\n  color: #6c8197;\n}\n::ng-deep .modalChannel .new-channel .channelForm .placeHolder .native-textarea {\n  height: 100vh;\n}\nion-toolbar {\n  --background: #6c8197;\n  position: fixed;\n  bottom: 0;\n}\n.channelBtn {\n  text-align: center;\n}\n.channelBtn button {\n  width: 30%;\n  background: #9cabba;\n  height: 40px;\n  border-radius: 4px;\n  color: #fff;\n  letter-spacing: 4px;\n  font-size: 16px;\n  outline: none;\n}\n.channelBtn .create {\n  float: right;\n}\n.channelBtn .cancel {\n  float: left;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9oYXJpL0RvY3VtZW50cy9wcm9qZWN0cy9wb3B3b3JrLWNhcGFjaXRvci9zcmMvYXBwL2NvbXBvbmVudHMvYWRkLWNoYW5uZWwvYWRkLWNoYW5uZWwuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvYWRkLWNoYW5uZWwvYWRkLWNoYW5uZWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxZQUFBO0FDQUo7QURFRTtFQUNFLHFCQUFBO0FDQUo7QURFRTtFQUNFLGdCQUFBO0FDQUo7QURDSTtFQUNFLFdBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0FDQ047QURFTTtFQUNFLDRCQUFBO0VBQ0Esd0JBQUE7RUFDQSxlQUFBO0VBQ0Esb0JBQUE7RUFDQSx1QkFBQTtBQ0FSO0FETE07RUFDRSw0QkFBQTtFQUNBLHdCQUFBO0VBQ0EsZUFBQTtFQUNBLG9CQUFBO0VBQ0EsdUJBQUE7QUNBUjtBRExNO0VBQ0UsNEJBQUE7RUFDQSx3QkFBQTtFQUNBLGVBQUE7RUFDQSxvQkFBQTtFQUNBLHVCQUFBO0FDQVI7QURMTTtFQUNFLDRCQUFBO0VBQ0Esd0JBQUE7RUFDQSxlQUFBO0VBQ0Esb0JBQUE7RUFDQSx1QkFBQTtBQ0FSO0FERU07RUFDRSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGNBQUE7QUNBUjtBRENRO0VBQ0UsYUFBQTtBQ0NWO0FES0E7RUFDRSxxQkFBQTtFQUNBLGVBQUE7RUFDQSxTQUFBO0FDRkY7QURJQTtFQUNFLGtCQUFBO0FDREY7QURFRTtFQUNFLFVBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxhQUFBO0FDQUo7QURFRTtFQUNFLFlBQUE7QUNBSjtBREVFO0VBQ0UsV0FBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9hZGQtY2hhbm5lbC9hZGQtY2hhbm5lbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjo6bmctZGVlcCAubW9kYWxDaGFubmVse1xuICAubW9kYWwtd3JhcHBlcntcbiAgICBtYXJnaW46IGF1dG87XG4gIH1cbiAgaW9uLWJhY2tkcm9wIHtcbiAgICBvcGFjaXR5OiAwICFpbXBvcnRhbnQ7XG4gIH1cbiAgLm5ldy1jaGFubmVse1xuICAgIG1hcmdpbi10b3A6IDI1cHg7XG4gICAgaDR7XG4gICAgICBjb2xvcjogI2ZmZjtcbiAgICAgIG1hcmdpbi10b3A6IDZweDtcbiAgICAgIGxldHRlci1zcGFjaW5nOiAycHg7XG4gICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgfVxuICAgIC5jaGFubmVsRm9ybXtcbiAgICAgIDo6cGxhY2Vob2xkZXJ7XG4gICAgICAgIC0tcGxhY2Vob2xkZXItY29sb3I6ICM2YzgxOTc7XG4gICAgICAgIC0tcGxhY2Vob2xkZXItb3BhY2l0eTogMTtcbiAgICAgICAgZm9udC1zaXplOiA0MXB4O1xuICAgICAgICBsZXR0ZXItc3BhY2luZzogMTNweDtcbiAgICAgICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG4gICAgICB9XG4gICAgICAucGxhY2VIb2xkZXJ7XG4gICAgICAgIGZvbnQtc2l6ZTogMjhweDtcbiAgICAgICAgbGV0dGVyLXNwYWNpbmc6IDJweDtcbiAgICAgICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG4gICAgICAgIGNvbG9yOiAjNmM4MTk3O1xuICAgICAgICAubmF0aXZlLXRleHRhcmVhe1xuICAgICAgICAgIGhlaWdodDogMTAwdmg7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbmlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjNmM4MTk3O1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIGJvdHRvbTogMDtcbn1cbi5jaGFubmVsQnRue1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGJ1dHRvbntcbiAgICB3aWR0aDogMzAlO1xuICAgIGJhY2tncm91bmQ6ICM5Y2FiYmE7XG4gICAgaGVpZ2h0OiA0MHB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBsZXR0ZXItc3BhY2luZzogNHB4O1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBvdXRsaW5lOiBub25lO1xuICB9XG4gIC5jcmVhdGV7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICB9XG4gIC5jYW5jZWx7XG4gICAgZmxvYXQ6IGxlZnQ7XG4gIH1cbn1cbiIsIjo6bmctZGVlcCAubW9kYWxDaGFubmVsIC5tb2RhbC13cmFwcGVyIHtcbiAgbWFyZ2luOiBhdXRvO1xufVxuOjpuZy1kZWVwIC5tb2RhbENoYW5uZWwgaW9uLWJhY2tkcm9wIHtcbiAgb3BhY2l0eTogMCAhaW1wb3J0YW50O1xufVxuOjpuZy1kZWVwIC5tb2RhbENoYW5uZWwgLm5ldy1jaGFubmVsIHtcbiAgbWFyZ2luLXRvcDogMjVweDtcbn1cbjo6bmctZGVlcCAubW9kYWxDaGFubmVsIC5uZXctY2hhbm5lbCBoNCB7XG4gIGNvbG9yOiAjZmZmO1xuICBtYXJnaW4tdG9wOiA2cHg7XG4gIGxldHRlci1zcGFjaW5nOiAycHg7XG4gIGZvbnQtc2l6ZTogMTZweDtcbn1cbjo6bmctZGVlcCAubW9kYWxDaGFubmVsIC5uZXctY2hhbm5lbCAuY2hhbm5lbEZvcm0gOjpwbGFjZWhvbGRlciB7XG4gIC0tcGxhY2Vob2xkZXItY29sb3I6ICM2YzgxOTc7XG4gIC0tcGxhY2Vob2xkZXItb3BhY2l0eTogMTtcbiAgZm9udC1zaXplOiA0MXB4O1xuICBsZXR0ZXItc3BhY2luZzogMTNweDtcbiAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG59XG46Om5nLWRlZXAgLm1vZGFsQ2hhbm5lbCAubmV3LWNoYW5uZWwgLmNoYW5uZWxGb3JtIC5wbGFjZUhvbGRlciB7XG4gIGZvbnQtc2l6ZTogMjhweDtcbiAgbGV0dGVyLXNwYWNpbmc6IDJweDtcbiAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG4gIGNvbG9yOiAjNmM4MTk3O1xufVxuOjpuZy1kZWVwIC5tb2RhbENoYW5uZWwgLm5ldy1jaGFubmVsIC5jaGFubmVsRm9ybSAucGxhY2VIb2xkZXIgLm5hdGl2ZS10ZXh0YXJlYSB7XG4gIGhlaWdodDogMTAwdmg7XG59XG5cbmlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjNmM4MTk3O1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIGJvdHRvbTogMDtcbn1cblxuLmNoYW5uZWxCdG4ge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4uY2hhbm5lbEJ0biBidXR0b24ge1xuICB3aWR0aDogMzAlO1xuICBiYWNrZ3JvdW5kOiAjOWNhYmJhO1xuICBoZWlnaHQ6IDQwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgY29sb3I6ICNmZmY7XG4gIGxldHRlci1zcGFjaW5nOiA0cHg7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgb3V0bGluZTogbm9uZTtcbn1cbi5jaGFubmVsQnRuIC5jcmVhdGUge1xuICBmbG9hdDogcmlnaHQ7XG59XG4uY2hhbm5lbEJ0biAuY2FuY2VsIHtcbiAgZmxvYXQ6IGxlZnQ7XG59Il19 */"

/***/ }),

/***/ "./src/app/components/add-channel/add-channel.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/components/add-channel/add-channel.component.ts ***!
  \*****************************************************************/
/*! exports provided: AddChannelComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddChannelComponent", function() { return AddChannelComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../services/auth.service */ "./src/services/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");








let AddChannelComponent = class AddChannelComponent {
    constructor(formBuilder, modalCtrl, authService, platform, router, events) {
        this.formBuilder = formBuilder;
        this.modalCtrl = modalCtrl;
        this.authService = authService;
        this.platform = platform;
        this.router = router;
        this.events = events;
        this.channelForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({});
        this.channelForm = this.formBuilder.group({
            title: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
        });
    }
    ngOnInit() {
        console.log(`${this.north} ${this.south} ${this.west} ${this.east}`);
        this.platform.ready().then();
        // this.initMap();
        this.showKeyboard();
    }
    // initMap() {
    //   if (this.geolocation) {
    //     const strictBounds = new google.maps.LatLngBounds();
    //     this.lng1 = strictBounds.getNorthEast().lng();
    //     this.lat1 = strictBounds.getNorthEast().lat();
    //     this.lng2 = strictBounds.getSouthWest().lng();
    //     this.lat2 = strictBounds.getSouthWest().lat();
    //     console.log(this.lng1, this.lat1, this.lng2, this.lat2);
    //   }
    // }
    showKeyboard() {
        setTimeout(() => {
            this.nameField.setFocus();
        }, 200);
    }
    addChannel() {
        const channel = {
            title: this.channelForm.value.title,
            north: this.north,
            south: this.south,
            west: this.west,
            east: this.east,
        };
        if (this.channelForm.valid) {
            this.authService.createChannels(channel).subscribe(res => {
                this.modalCtrl.dismiss().then();
            });
            this.router.navigate(['/main/message']).then(() => {
                this.events.publish("public_message_posted");
            });
        }
    }
    cancel() {
        this.modalCtrl.dismiss().then();
    }
};
AddChannelComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Events"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('gmap', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], AddChannelComponent.prototype, "gmapElement", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('focus', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], AddChannelComponent.prototype, "nameField", void 0);
AddChannelComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-add-channel',
        template: __webpack_require__(/*! raw-loader!./add-channel.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/add-channel/add-channel.component.html"),
        styles: [__webpack_require__(/*! ./add-channel.component.scss */ "./src/app/components/add-channel/add-channel.component.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
        _services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"],
        _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Events"]])
], AddChannelComponent);



/***/ }),

/***/ "./src/app/pages/map/map.module.ts":
/*!*****************************************!*\
  !*** ./src/app/pages/map/map.module.ts ***!
  \*****************************************/
/*! exports provided: MapPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MapPageModule", function() { return MapPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _map_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./map.page */ "./src/app/pages/map/map.page.ts");
/* harmony import */ var _components_add_channel_add_channel_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components/add-channel/add-channel.component */ "./src/app/components/add-channel/add-channel.component.ts");
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../components/components.module */ "./src/app/components/components.module.ts");









const routes = [
    {
        path: '',
        component: _map_page__WEBPACK_IMPORTED_MODULE_6__["MapPage"]
    }
];
let MapPageModule = class MapPageModule {
};
MapPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _components_components_module__WEBPACK_IMPORTED_MODULE_8__["ComponentsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_map_page__WEBPACK_IMPORTED_MODULE_6__["MapPage"], _components_add_channel_add_channel_component__WEBPACK_IMPORTED_MODULE_7__["AddChannelComponent"]],
        entryComponents: [_components_add_channel_add_channel_component__WEBPACK_IMPORTED_MODULE_7__["AddChannelComponent"]]
    })
], MapPageModule);



/***/ }),

/***/ "./src/app/pages/map/map.page.scss":
/*!*****************************************!*\
  !*** ./src/app/pages/map/map.page.scss ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "#map {\n  width: 100%;\n  height: calc(100vh - 50px);\n}\n\n.footer-tabs {\n  text-align: center;\n}\n\n.footer-tabs .settings, .footer-tabs .qr-code, .footer-tabs .location {\n  width: 30%;\n  display: inline-block;\n}\n\n.footer-tabs .settings button, .footer-tabs .qr-code button, .footer-tabs .location button {\n  background: none;\n  outline: none;\n}\n\n.footer-tabs .settings button .location-color, .footer-tabs .qr-code button .location-color, .footer-tabs .location button .location-color {\n  color: #ff0046;\n  font-size: 30px;\n}\n\n.footer-tabs .settings button .sett-icon, .footer-tabs .qr-code button .sett-icon, .footer-tabs .location button .sett-icon {\n  color: grey;\n  font-size: 30px;\n}\n\n.footer-tabs .settings button .qr, .footer-tabs .qr-code button .qr, .footer-tabs .location button .qr {\n  font-size: 30px;\n  color: grey;\n}\n\n.shout-icon {\n  position: absolute;\n  z-index: 7777;\n  width: 40px;\n  height: 40px;\n  right: 20px;\n  top: 20px;\n  border-radius: 6px;\n  box-shadow: 0px 0px 10px #888888;\n  background-color: #ff4560;\n}\n\n.foot {\n  box-shadow: 0px 0px 10px #888888;\n  position: absolute;\n  z-index: 99999;\n  background: #fff;\n  left: 0px;\n  right: 0px;\n  bottom: 0px;\n  border-radius: 0px;\n}\n\n.search-place {\n  box-shadow: 0px 0px 10px #888888;\n  position: absolute;\n  z-index: 99999;\n  background: #fff;\n  left: 20px;\n  right: 20px;\n  top: 20px;\n  border-radius: 6px;\n}\n\n.search-place .search-pl {\n  position: absolute;\n  top: 8px;\n  left: 15px;\n  font-size: 24px;\n  color: gray;\n}\n\n.search-place .searchinput {\n  padding-left: 20px;\n  padding-right: 20px;\n}\n\n.search-place ion-input {\n  margin-left: 50px;\n  text-align: left;\n  letter-spacing: 1px;\n}\n\n.object-info {\n  position: relative;\n  bottom: 60;\n  width: 100%;\n}\n\n.object-info h1 {\n  color: #fff;\n  margin-left: 15px;\n  font-size: 16px;\n}\n\n.object-info span {\n  display: block;\n  color: #fff;\n  margin-left: 15px;\n  font-size: 13px;\n  padding: 8px 0;\n}\n\n.object-info .info-block {\n  text-align: left;\n  display: block;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9oYXJpL0RvY3VtZW50cy9wcm9qZWN0cy9wb3B3b3JrLWNhcGFjaXRvci9zcmMvYXBwL3BhZ2VzL21hcC9tYXAucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tYXAvbWFwLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7RUFDQSwwQkFBQTtBQ0NGOztBRENBO0VBQ0ksa0JBQUE7QUNFSjs7QURESTtFQUNFLFVBQUE7RUFDQSxxQkFBQTtBQ0dOOztBREZNO0VBQ0UsZ0JBQUE7RUFDQSxhQUFBO0FDSVI7O0FESFE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtBQ0tWOztBREhRO0VBQ0UsV0FBQTtFQUNBLGVBQUE7QUNLVjs7QURIUTtFQUNFLGVBQUE7RUFDQSxXQUFBO0FDS1Y7O0FEQ0U7RUFDRSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQ0FBQTtFQUNBLHlCQUFBO0FDRUo7O0FEQ0U7RUFDRSxnQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QUNFSjs7QURBQTtFQUNFLGdDQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxrQkFBQTtBQ0dGOztBREZFO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0FDSUo7O0FEREU7RUFDRSxrQkFBQTtFQUNBLG1CQUFBO0FDR0o7O0FEREU7RUFDRSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUNHSjs7QURBRTtFQUNFLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7QUNHSjs7QURGSTtFQUNFLFdBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUNJTjs7QURGSTtFQUNFLGNBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBQ0lOOztBREZNO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0FDSVIiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9tYXAvbWFwLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiNtYXAge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiBjYWxjKDEwMHZoIC0gNTBweCk7XG59XG4uZm9vdGVyLXRhYnN7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIC5zZXR0aW5ncywgLnFyLWNvZGUsLmxvY2F0aW9uIHtcbiAgICAgIHdpZHRoOiAzMCU7XG4gICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICBidXR0b257XG4gICAgICAgIGJhY2tncm91bmQ6IG5vbmU7XG4gICAgICAgIG91dGxpbmU6IG5vbmU7XG4gICAgICAgIC5sb2NhdGlvbi1jb2xvcntcbiAgICAgICAgICBjb2xvcjogI2ZmMDA0NjtcbiAgICAgICAgICBmb250LXNpemU6IDMwcHg7XG4gICAgICAgIH1cbiAgICAgICAgLnNldHQtaWNvbntcbiAgICAgICAgICBjb2xvcjogZ3JleTtcbiAgICAgICAgICBmb250LXNpemU6IDMwcHg7XG4gICAgICAgIH1cbiAgICAgICAgLnFye1xuICAgICAgICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICAgICAgICBjb2xvcjogZ3JleTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC5zaG91dC1pY29ue1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB6LWluZGV4OiA3Nzc3O1xuICAgIHdpZHRoOjQwcHg7XG4gICAgaGVpZ2h0OjQwcHg7XG4gICAgcmlnaHQ6IDIwcHg7XG4gICAgdG9wOiAyMHB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgICBib3gtc2hhZG93OiAwcHggMHB4IDEwcHggIzg4ODg4ODtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmY0NTYwO1xuICB9XG5cbiAgLmZvb3Qge1xuICAgIGJveC1zaGFkb3c6IDBweCAwcHggMTBweCAjODg4ODg4O1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB6LWluZGV4OiA5OTk5OTtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICAgIGxlZnQ6IDBweDtcbiAgICByaWdodDogMHB4O1xuICAgIGJvdHRvbTogMHB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDBweDtcbiAgfVxuLnNlYXJjaC1wbGFjZXtcbiAgYm94LXNoYWRvdzogMHB4IDBweCAxMHB4ICM4ODg4ODg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgei1pbmRleDogOTk5OTk7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGxlZnQ6IDIwcHg7XG4gIHJpZ2h0OiAyMHB4O1xuICB0b3A6IDIwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgLnNlYXJjaC1wbHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiA4cHg7XG4gICAgbGVmdDogMTVweDtcbiAgICBmb250LXNpemU6IDI0cHg7XG4gICAgY29sb3I6IGdyYXk7XG4gIH1cblxuICAuc2VhcmNoaW5wdXQge1xuICAgIHBhZGRpbmctbGVmdDogMjBweDtcbiAgICBwYWRkaW5nLXJpZ2h0OiAyMHB4O1xuICB9XG4gIGlvbi1pbnB1dHtcbiAgICBtYXJnaW4tbGVmdDo1MHB4O1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbiAgfVxufVxuICAub2JqZWN0LWluZm97XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIGJvdHRvbTogNjA7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaDF7XG4gICAgICBjb2xvcjogI2ZmZjtcbiAgICAgIG1hcmdpbi1sZWZ0OiAxNXB4O1xuICAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgIH1cbiAgICBzcGFue1xuICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICBjb2xvcjogI2ZmZjtcbiAgICAgIG1hcmdpbi1sZWZ0OiAxNXB4O1xuICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgcGFkZGluZzogOHB4IDA7XG4gICAgfVxuICAgICAgLmluZm8tYmxvY2t7XG4gICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cbiAgfVxuIiwiI21hcCB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IGNhbGMoMTAwdmggLSA1MHB4KTtcbn1cblxuLmZvb3Rlci10YWJzIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLmZvb3Rlci10YWJzIC5zZXR0aW5ncywgLmZvb3Rlci10YWJzIC5xci1jb2RlLCAuZm9vdGVyLXRhYnMgLmxvY2F0aW9uIHtcbiAgd2lkdGg6IDMwJTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xufVxuLmZvb3Rlci10YWJzIC5zZXR0aW5ncyBidXR0b24sIC5mb290ZXItdGFicyAucXItY29kZSBidXR0b24sIC5mb290ZXItdGFicyAubG9jYXRpb24gYnV0dG9uIHtcbiAgYmFja2dyb3VuZDogbm9uZTtcbiAgb3V0bGluZTogbm9uZTtcbn1cbi5mb290ZXItdGFicyAuc2V0dGluZ3MgYnV0dG9uIC5sb2NhdGlvbi1jb2xvciwgLmZvb3Rlci10YWJzIC5xci1jb2RlIGJ1dHRvbiAubG9jYXRpb24tY29sb3IsIC5mb290ZXItdGFicyAubG9jYXRpb24gYnV0dG9uIC5sb2NhdGlvbi1jb2xvciB7XG4gIGNvbG9yOiAjZmYwMDQ2O1xuICBmb250LXNpemU6IDMwcHg7XG59XG4uZm9vdGVyLXRhYnMgLnNldHRpbmdzIGJ1dHRvbiAuc2V0dC1pY29uLCAuZm9vdGVyLXRhYnMgLnFyLWNvZGUgYnV0dG9uIC5zZXR0LWljb24sIC5mb290ZXItdGFicyAubG9jYXRpb24gYnV0dG9uIC5zZXR0LWljb24ge1xuICBjb2xvcjogZ3JleTtcbiAgZm9udC1zaXplOiAzMHB4O1xufVxuLmZvb3Rlci10YWJzIC5zZXR0aW5ncyBidXR0b24gLnFyLCAuZm9vdGVyLXRhYnMgLnFyLWNvZGUgYnV0dG9uIC5xciwgLmZvb3Rlci10YWJzIC5sb2NhdGlvbiBidXR0b24gLnFyIHtcbiAgZm9udC1zaXplOiAzMHB4O1xuICBjb2xvcjogZ3JleTtcbn1cblxuLnNob3V0LWljb24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHotaW5kZXg6IDc3Nzc7XG4gIHdpZHRoOiA0MHB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIHJpZ2h0OiAyMHB4O1xuICB0b3A6IDIwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgYm94LXNoYWRvdzogMHB4IDBweCAxMHB4ICM4ODg4ODg7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZjQ1NjA7XG59XG5cbi5mb290IHtcbiAgYm94LXNoYWRvdzogMHB4IDBweCAxMHB4ICM4ODg4ODg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgei1pbmRleDogOTk5OTk7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGxlZnQ6IDBweDtcbiAgcmlnaHQ6IDBweDtcbiAgYm90dG9tOiAwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDBweDtcbn1cblxuLnNlYXJjaC1wbGFjZSB7XG4gIGJveC1zaGFkb3c6IDBweCAwcHggMTBweCAjODg4ODg4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHotaW5kZXg6IDk5OTk5O1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICBsZWZ0OiAyMHB4O1xuICByaWdodDogMjBweDtcbiAgdG9wOiAyMHB4O1xuICBib3JkZXItcmFkaXVzOiA2cHg7XG59XG4uc2VhcmNoLXBsYWNlIC5zZWFyY2gtcGwge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogOHB4O1xuICBsZWZ0OiAxNXB4O1xuICBmb250LXNpemU6IDI0cHg7XG4gIGNvbG9yOiBncmF5O1xufVxuLnNlYXJjaC1wbGFjZSAuc2VhcmNoaW5wdXQge1xuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDIwcHg7XG59XG4uc2VhcmNoLXBsYWNlIGlvbi1pbnB1dCB7XG4gIG1hcmdpbi1sZWZ0OiA1MHB4O1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBsZXR0ZXItc3BhY2luZzogMXB4O1xufVxuXG4ub2JqZWN0LWluZm8ge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGJvdHRvbTogNjA7XG4gIHdpZHRoOiAxMDAlO1xufVxuLm9iamVjdC1pbmZvIGgxIHtcbiAgY29sb3I6ICNmZmY7XG4gIG1hcmdpbi1sZWZ0OiAxNXB4O1xuICBmb250LXNpemU6IDE2cHg7XG59XG4ub2JqZWN0LWluZm8gc3BhbiB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBjb2xvcjogI2ZmZjtcbiAgbWFyZ2luLWxlZnQ6IDE1cHg7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgcGFkZGluZzogOHB4IDA7XG59XG4ub2JqZWN0LWluZm8gLmluZm8tYmxvY2sge1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBkaXNwbGF5OiBibG9jaztcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/map/map.page.ts":
/*!***************************************!*\
  !*** ./src/app/pages/map/map.page.ts ***!
  \***************************************/
/*! exports provided: MapPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MapPage", function() { return MapPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../services/auth.service */ "./src/services/auth.service.ts");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");
/* harmony import */ var _components_add_channel_add_channel_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/add-channel/add-channel.component */ "./src/app/components/add-channel/add-channel.component.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");





const { Geolocation } = _capacitor_core__WEBPACK_IMPORTED_MODULE_4__["Plugins"];


let MapPage = class MapPage {
    constructor(router, authService, modalController) {
        this.router = router;
        this.authService = authService;
        this.modalController = modalController;
        this.time = null;
        this.hour = 7;
        this.displayHour = "7:00 AM";
        this.day = 0;
        this.user = [];
        console.log("--------------------");
        this.geofenceInit();
    }
    geofenceInit() {
        console.log("calling Geofence");
    }
    getDisplayTime() {
        let t = this.hour;
        let am = "am";
        if (t > 11.5) {
            am = "pm";
        }
    }
    ngOnInit() {
        this.initMap();
    }
    searchPlaces(e) {
        clearTimeout(this.time);
        this.time = setTimeout(() => {
            this.authService.searchPlace(this.lat, this.lng, e.target.value).subscribe(place => {
                this.places = '';
                this.places = place;
                this.placeMarkers();
                this.showPlaceInfo = this.places[0];
                const center = new google.maps.LatLng(this.places[0].lat - 0.1, this.places[0].lng);
                this.map.setCenter(center);
            });
        }, 500);
    }
    initMap() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const position = yield Geolocation.getCurrentPosition();
            this.lat = position.coords.latitude;
            this.lng = position.coords.longitude;
            this.authService.getPlaces(this.lat, this.lng).subscribe(places => {
                this.places = places;
                this.placeMarkers();
            });
            this.myLocation = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
            this.map = new google.maps.Map(this.gmapElement.nativeElement, {
                center: this.myLocation,
                zoom: 1,
                mapTypeControl: false,
                streetViewControl: false,
                panControl: false,
                fullscreenControl: false,
                rotateControl: false,
                zoomControl: true,
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                styles: [
                    {
                        'featureType': 'water',
                        'elementType': 'geometry',
                        'stylers': [
                            {
                                'color': '#e9e9e9'
                            },
                            {
                                'lightness': 17
                            }
                        ]
                    },
                    {
                        'featureType': 'landscape',
                        'elementType': 'geometry',
                        'stylers': [
                            {
                                'color': '#f5f5f5'
                            },
                            {
                                'lightness': 20
                            }
                        ]
                    },
                    {
                        'featureType': 'road.highway',
                        'elementType': 'geometry.fill',
                        'stylers': [
                            {
                                'color': '#ffffff'
                            },
                            {
                                'lightness': 17
                            }
                        ]
                    },
                    {
                        'featureType': 'road.highway',
                        'elementType': 'geometry.stroke',
                        'stylers': [
                            {
                                'color': '#ffffff'
                            },
                            {
                                'lightness': 29
                            },
                            {
                                'weight': 0.2
                            }
                        ]
                    },
                    {
                        'featureType': 'road.arterial',
                        'elementType': 'geometry',
                        'stylers': [
                            {
                                'color': '#ffffff'
                            },
                            {
                                'lightness': 18
                            }
                        ]
                    },
                    {
                        'featureType': 'road.local',
                        'elementType': 'geometry',
                        'stylers': [
                            {
                                'color': '#ffffff'
                            },
                            {
                                'lightness': 16
                            }
                        ]
                    },
                    {
                        'featureType': 'poi',
                        'elementType': 'geometry',
                        'stylers': [
                            {
                                'color': '#f5f5f5'
                            },
                            {
                                'lightness': 21
                            }
                        ]
                    },
                    {
                        'featureType': 'poi.park',
                        'elementType': 'geometry',
                        'stylers': [
                            {
                                'color': '#dedede'
                            },
                            {
                                'lightness': 21
                            }
                        ]
                    },
                    {
                        'elementType': 'labels.text.stroke',
                        'stylers': [
                            {
                                'visibility': 'on'
                            },
                            {
                                'color': '#ffffff'
                            },
                            {
                                'lightness': 16
                            }
                        ]
                    },
                    {
                        'elementType': 'labels.text.fill',
                        'stylers': [
                            {
                                'saturation': 36
                            },
                            {
                                'color': '#333333'
                            },
                            {
                                'lightness': 40
                            }
                        ]
                    },
                    {
                        'elementType': 'labels.icon',
                        'stylers': [
                            {
                                'visibility': 'off'
                            }
                        ]
                    },
                    {
                        'featureType': 'transit',
                        'elementType': 'geometry',
                        'stylers': [
                            {
                                'color': '#f2f2f2'
                            },
                            {
                                'lightness': 19
                            }
                        ]
                    },
                    {
                        'featureType': 'administrative',
                        'elementType': 'geometry.fill',
                        'stylers': [
                            {
                                'color': '#fefefe'
                            },
                            {
                                'lightness': 20
                            }
                        ]
                    },
                    {
                        'featureType': 'administrative',
                        'elementType': 'geometry.stroke',
                        'stylers': [
                            {
                                'color': '#fefefe'
                            },
                            {
                                'lightness': 17
                            },
                            {
                                'weight': 1.2
                            }
                        ]
                    }
                ]
            });
        });
    }
    placeMarkers() {
        // debugger;
        this.map = new google.maps.Map(this.gmapElement.nativeElement, {
            center: new google.maps.LatLng(32.7767, -96.7970),
            zoom: 10,
            mapTypeControl: false,
            streetViewControl: false,
            panControl: false,
            fullscreenControl: false,
            rotateControl: false,
            zoomControl: false,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            styles: [
                {
                    'featureType': 'all',
                    'elementType': 'labels.text.fill',
                    'stylers': [
                        {
                            'saturation': 36
                        },
                        {
                            'color': '#333333'
                        },
                        {
                            'lightness': 40
                        }
                    ]
                },
                {
                    'featureType': 'all',
                    'elementType': 'labels.text.stroke',
                    'stylers': [
                        {
                            'visibility': 'on'
                        },
                        {
                            'color': '#ffffff'
                        },
                        {
                            'lightness': 16
                        }
                    ]
                },
                {
                    'featureType': 'all',
                    'elementType': 'labels.icon',
                    'stylers': [
                        {
                            'visibility': 'off'
                        }
                    ]
                },
                {
                    'featureType': 'administrative',
                    'elementType': 'geometry.fill',
                    'stylers': [
                        {
                            'color': '#fefefe'
                        },
                        {
                            'lightness': 20
                        }
                    ]
                },
                {
                    'featureType': 'administrative',
                    'elementType': 'geometry.stroke',
                    'stylers': [
                        {
                            'color': '#fefefe'
                        },
                        {
                            'lightness': 17
                        },
                        {
                            'weight': 1.2
                        }
                    ]
                },
                {
                    'featureType': 'landscape',
                    'elementType': 'geometry',
                    'stylers': [
                        {
                            'color': '#f5f5f5'
                        },
                        {
                            'lightness': 20
                        }
                    ]
                },
                {
                    'featureType': 'poi',
                    'elementType': 'geometry',
                    'stylers': [
                        {
                            'color': '#f5f5f5'
                        },
                        {
                            'lightness': 21
                        }
                    ]
                },
                {
                    'featureType': 'poi.park',
                    'elementType': 'geometry',
                    'stylers': [
                        {
                            'color': '#dedede'
                        },
                        {
                            'lightness': 21
                        }
                    ]
                },
                {
                    'featureType': 'road.highway',
                    'elementType': 'geometry.fill',
                    'stylers': [
                        {
                            'color': '#d6d6d6'
                        },
                        {
                            'lightness': 17
                        }
                    ]
                },
                {
                    'featureType': 'road.highway',
                    'elementType': 'geometry.stroke',
                    'stylers': [
                        {
                            'color': '#ffffff'
                        },
                        {
                            'lightness': 29
                        },
                        {
                            'weight': 0.2
                        }
                    ]
                },
                {
                    'featureType': 'road.arterial',
                    'elementType': 'geometry',
                    'stylers': [
                        {
                            'color': '#ffffff'
                        },
                        {
                            'lightness': 18
                        }
                    ]
                },
                {
                    'featureType': 'road.local',
                    'elementType': 'all',
                    'stylers': [
                        {
                            'visibility': 'on'
                        }
                    ]
                },
                {
                    'featureType': 'road.local',
                    'elementType': 'geometry',
                    'stylers': [
                        {
                            'color': '#ffffff'
                        },
                        {
                            'lightness': 16
                        },
                        {
                            'visibility': 'off'
                        }
                    ]
                },
                {
                    'featureType': 'road.local',
                    'elementType': 'labels.text',
                    'stylers': [
                        {
                            'visibility': 'off'
                        }
                    ]
                },
                {
                    'featureType': 'transit',
                    'elementType': 'geometry',
                    'stylers': [
                        {
                            'color': '#f2f2f2'
                        },
                        {
                            'lightness': 19
                        }
                    ]
                },
                {
                    'featureType': 'water',
                    'elementType': 'geometry',
                    'stylers': [
                        {
                            'color': '#e9e9e9'
                        },
                        {
                            'lightness': 17
                        }
                    ]
                }
            ]
        });
        const markers = [];
        for (let i = 0; i < this.places.length; i++) {
            const pos = new google.maps.LatLng(this.places[i].lat, this.places[i].lng);
            let iconUrl = '../../assets/imgs/coffee-map-icon-trans.png';
            if (this.places[i].people === 0) {
                iconUrl = '../../assets/imgs/coffee-map-icon-trans.png';
            }
            if (this.places[i].poptype === 1) {
                if (this.places[i].people > 0) {
                    iconUrl = '../../assets/imgs/coworking-map-icon-trans.png';
                }
                else {
                    iconUrl = '../../assets/imgs/coworking-map-icon-trans.png';
                }
            }
            let labelText = this.places[i].people + '';
            // if (this.places[i].people === 0) {
            labelText = ' ';
            //}
            const place = this.places[i];
            const marker = new google.maps.Marker({
                position: pos,
                map: this.map,
                label: { text: labelText, color: 'white' },
                icon: {
                    scaledSize: new google.maps.Size(36, 45),
                    url: iconUrl,
                },
            });
            marker.addListener('click', function () {
                if (this.selectedMarker) {
                    this.selectedMarker.setAnimation(null);
                }
                this.selectedMarker = marker;
                this.selectedMarker.setAnimation(google.maps.Animation.BOUNCE);
                // this.map.panTo(new google.maps.LatLng(place.lat, place.lng));
            }.bind(this));
            markers[i] = marker;
            this.places[i].marker = marker;
            google.maps.event.addListener(markers[i], 'click', () => {
                this.showPlaceInfo = this.places.filter(item => item.id === markers[i].id)[0];
                console.log(this.showPlaceInfo);
            });
            google.maps.event.addListener(this.map, 'bounds_changed', () => {
                const strictBounds = this.map.getBounds();
                this.north = strictBounds.getNorthEast().lng();
                this.south = strictBounds.getNorthEast().lat();
                this.west = strictBounds.getSouthWest().lng();
                this.east = strictBounds.getSouthWest().lat();
            });
            markers[i]['id'] = this.places[i].id;
        }
    }
    addChannelModal() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _components_add_channel_add_channel_component__WEBPACK_IMPORTED_MODULE_5__["AddChannelComponent"],
                cssClass: 'modalChannel',
                componentProps: {
                    north: this.north,
                    south: this.south,
                    west: this.west,
                    east: this.east,
                }
            });
            return yield modal.present();
        });
    }
};
MapPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('gmap', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], MapPage.prototype, "gmapElement", void 0);
MapPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-map',
        template: __webpack_require__(/*! raw-loader!./map.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/map/map.page.html"),
        styles: [__webpack_require__(/*! ./map.page.scss */ "./src/app/pages/map/map.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"]])
], MapPage);



/***/ })

}]);
//# sourceMappingURL=map-map-module-es2015.js.map