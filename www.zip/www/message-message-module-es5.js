(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["message-message-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/components/messages/messages.component.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/messages/messages.component.html ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!--<div *ngFor=\"let mess of messages\" class=\"message\">-->\n<!--  <div class=\"fromMessage\">-->\n<!--    <img src=\"{{ mess.photo }}\"alt=\"avatar6\">-->\n<!--    <p>{{ mess.fullname }}</p>-->\n<!--  </div>-->\n<!--  <div class=\"dateMessage\">-->\n<!--    <span class=\"dateMess\">{{ mess.created | amTimeAgo }}</span>-->\n<!--  </div>-->\n<!--  <p class=\"textMess\">{{ mess.message }}</p>-->\n<!--</div>-->\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/message/message.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/message/message.page.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar>\n        <ion-title>\n          <span style=\"font-size:0.8em;\">Global Peace Factory Coffee House</span>\n        </ion-title>\n    </ion-toolbar>\n</ion-header>\n<ion-content color=\"light\">\n  <div>\n    <div >\n        <div (click)=\"goToPublicMess(mess)\" style=\"background-color:#fff;margin:10px;border-radius:4px;font-size:0.9em;padding:10px;display:flex;flex-direction: row ;\" *ngFor=\"let mess of messages\" > \n          <span style=\"flex: none;\" >\n          <img [src]=\"mess.photo\" style=\"margin-right:5px;border-radius:50px;overflow:hidden;width:50px;height:50px;\" > \n        </span>  \n            <div style=\"flex:1\">\n              <div style=\"display:flex;flex-direction: row ;\" >\n                <span style=\"flex:1;font-size:0.8em;color:#666;\">\n                    {{mess.fullname}}\n                </span>\n                <span style=\"flex: none; align-self:flex-end; font-size:0.8em;color:#666;\" >{{ mess.created | amTimeAgo }}</span>\n              </div> \n              <div style=\"color:#666;\" >\n                  <span style=\"font-size:0.8em;color:#ff0077\" >Mudsmith Coffee House</span>\n              <div style=\"color:#000;font-size:0.8em;\">{{mess.title}}</div>\n\n              <div style=\"display:flex;flex-direction: row;\" >\n                  <span (click) = \"addMessage($event, mess)\" style=\"flex:1;font-size:0.8em;color:#666;vertical-align: middle;\">\n                      <div style=\"vertical-align: middle;margin-top:3px;margin-right:5px;padding:5px;background-color:#f1f1f1;border-radius:4px;color:#666;\">leave a comment</div>\n                  </span>\n                  <span style=\"padding-top:5px;padding-bottom:5px;vertical-align: top;flex: none; align-self:flex-end; font-size:0.8em;color:#666;\" >235 comments</span>\n                </div> \n           \n              </div>\n\n\n            </div>\n        </div>\n    </div>\n\n\n    <div *ngIf=\"private\">\n      <div (click)=\"goToPrivateMess(mess.id)\" *ngFor=\"let mess of messages\" class=\"message\">\n        <div class=\"fromMessage\">\n          <img src=\"{{ mess.photo }}\" alt=\"avatar6\">\n          <p class=\"textMess\">{{ mess.title }}</p>\n          <p>{{ mess.fullname }}</p>\n        </div>\n        <div class=\"dateMessage\">\n          <span class=\"dateMess\">{{ mess.created | amTimeAgo }}</span>\n        </div>\n        <p class=\"textMess\">{{ mess.title }}</p>\n      </div>\n    </div>\n  </div>\n</ion-content>\n\n\n"

/***/ }),

/***/ "./src/app/components/messages/messages.component.scss":
/*!*************************************************************!*\
  !*** ./src/app/components/messages/messages.component.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".message .textMess {\n  font-weight: bold;\n  font-family: sans-serif;\n  line-height: 25px;\n  height: 50px;\n  overflow: hidden;\n  margin-top: 12px;\n  color: #12273d;\n  font-size: 17px;\n  border-bottom: 2px solid #f2f3f8;\n  margin-left: 4px;\n}\n.message .fromMessage {\n  width: 60%;\n  display: inline-block;\n}\n.message .fromMessage img {\n  width: 40px;\n  border-radius: 100%;\n  vertical-align: middle;\n}\n.message .fromMessage p {\n  display: inline-block;\n  margin: 0;\n  margin-left: 10px;\n  color: #6b798b;\n  font-size: 15px;\n  font-family: sans-serif;\n  letter-spacing: 0.5px;\n}\n.message .dateMessage {\n  width: 40%;\n  display: inline-block;\n  text-align: right;\n}\n.message .dateMessage .dateMess {\n  color: #6b798b;\n  font-size: 15px;\n  font-family: sans-serif;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9oYXJpL0RvY3VtZW50cy9wcm9qZWN0cy9wb3B3b3JrLWNhcGFjaXRvci9zcmMvYXBwL2NvbXBvbmVudHMvbWVzc2FnZXMvbWVzc2FnZXMuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvbWVzc2FnZXMvbWVzc2FnZXMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxpQkFBQTtFQUNBLHVCQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0NBQUE7RUFDQSxnQkFBQTtBQ0FKO0FERUU7RUFDRSxVQUFBO0VBQ0EscUJBQUE7QUNBSjtBRENJO0VBQ0UsV0FBQTtFQUNBLG1CQUFBO0VBQ0Esc0JBQUE7QUNDTjtBRENJO0VBQ0UscUJBQUE7RUFDQSxTQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLHVCQUFBO0VBQ0EscUJBQUE7QUNDTjtBREVFO0VBQ0UsVUFBQTtFQUNBLHFCQUFBO0VBQ0EsaUJBQUE7QUNBSjtBRENJO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSx1QkFBQTtBQ0NOIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9tZXNzYWdlcy9tZXNzYWdlcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tZXNzYWdle1xuICAudGV4dE1lc3N7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG4gICAgbGluZS1oZWlnaHQ6IDI1cHg7XG4gICAgaGVpZ2h0OiA1MHB4O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgbWFyZ2luLXRvcDogMTJweDtcbiAgICBjb2xvcjogIzEyMjczZDtcbiAgICBmb250LXNpemU6IDE3cHg7XG4gICAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkICNmMmYzZjg7XG4gICAgbWFyZ2luLWxlZnQ6IDRweDtcbiAgfVxuICAuZnJvbU1lc3NhZ2V7XG4gICAgd2lkdGg6IDYwJTtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgaW1ne1xuICAgICAgd2lkdGg6IDQwcHg7XG4gICAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICAgICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgICB9XG4gICAgcHtcbiAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICAgIG1hcmdpbjogMDtcbiAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgICAgY29sb3I6ICM2Yjc5OGI7XG4gICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcbiAgICAgIGxldHRlci1zcGFjaW5nOiAwLjVweDtcbiAgICB9XG4gIH1cbiAgLmRhdGVNZXNzYWdle1xuICAgIHdpZHRoOiA0MCU7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICAgIC5kYXRlTWVzc3tcbiAgICAgIGNvbG9yOiAjNmI3OThiO1xuICAgICAgZm9udC1zaXplOiAxNXB4O1xuICAgICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG4gICAgfVxuICB9XG59XG4iLCIubWVzc2FnZSAudGV4dE1lc3Mge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG4gIGxpbmUtaGVpZ2h0OiAyNXB4O1xuICBoZWlnaHQ6IDUwcHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIG1hcmdpbi10b3A6IDEycHg7XG4gIGNvbG9yOiAjMTIyNzNkO1xuICBmb250LXNpemU6IDE3cHg7XG4gIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjZjJmM2Y4O1xuICBtYXJnaW4tbGVmdDogNHB4O1xufVxuLm1lc3NhZ2UgLmZyb21NZXNzYWdlIHtcbiAgd2lkdGg6IDYwJTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xufVxuLm1lc3NhZ2UgLmZyb21NZXNzYWdlIGltZyB7XG4gIHdpZHRoOiA0MHB4O1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xufVxuLm1lc3NhZ2UgLmZyb21NZXNzYWdlIHAge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIG1hcmdpbjogMDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIGNvbG9yOiAjNmI3OThiO1xuICBmb250LXNpemU6IDE1cHg7XG4gIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xuICBsZXR0ZXItc3BhY2luZzogMC41cHg7XG59XG4ubWVzc2FnZSAuZGF0ZU1lc3NhZ2Uge1xuICB3aWR0aDogNDAlO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xufVxuLm1lc3NhZ2UgLmRhdGVNZXNzYWdlIC5kYXRlTWVzcyB7XG4gIGNvbG9yOiAjNmI3OThiO1xuICBmb250LXNpemU6IDE1cHg7XG4gIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/components/messages/messages.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/components/messages/messages.component.ts ***!
  \***********************************************************/
/*! exports provided: MessagesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessagesComponent", function() { return MessagesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../services/auth.service */ "./src/services/auth.service.ts");



var MessagesComponent = /** @class */ (function () {
    function MessagesComponent(authService) {
        this.authService = authService;
        this.messages = [];
    }
    MessagesComponent.prototype.ngOnInit = function () {
        // this.authService.getMessage().subscribe((mess: any ) => {
        //   console.log(mess);
        //   this.messages = mess;
        // });
    };
    MessagesComponent.ctorParameters = function () { return [
        { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] }
    ]; };
    MessagesComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-messages',
            template: __webpack_require__(/*! raw-loader!./messages.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/messages/messages.component.html"),
            styles: [__webpack_require__(/*! ./messages.component.scss */ "./src/app/components/messages/messages.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]])
    ], MessagesComponent);
    return MessagesComponent;
}());



/***/ }),

/***/ "./src/app/pages/message/message.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/message/message.module.ts ***!
  \*************************************************/
/*! exports provided: MessagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessagePageModule", function() { return MessagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _message_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./message.page */ "./src/app/pages/message/message.page.ts");
/* harmony import */ var _components_messages_messages_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components/messages/messages.component */ "./src/app/components/messages/messages.component.ts");
/* harmony import */ var ngx_moment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ngx-moment */ "./node_modules/ngx-moment/fesm5/ngx-moment.js");









var routes = [
    {
        path: '',
        component: _message_page__WEBPACK_IMPORTED_MODULE_6__["MessagePage"]
    }
];
var MessagePageModule = /** @class */ (function () {
    function MessagePageModule() {
    }
    MessagePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                ngx_moment__WEBPACK_IMPORTED_MODULE_8__["MomentModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_message_page__WEBPACK_IMPORTED_MODULE_6__["MessagePage"], _components_messages_messages_component__WEBPACK_IMPORTED_MODULE_7__["MessagesComponent"]],
            entryComponents: [],
        })
    ], MessagePageModule);
    return MessagePageModule;
}());



/***/ }),

/***/ "./src/app/pages/message/message.page.scss":
/*!*************************************************!*\
  !*** ./src/app/pages/message/message.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".myClass {\n  background-color: lightyellow;\n  height: 100%;\n  width: 100%;\n}\n\n.addChannel {\n  float: right;\n  font-size: 32px;\n  color: #12416a;\n}\n\n.messBtn {\n  padding-bottom: 14px;\n  right: 0;\n  left: 0;\n  margin-right: auto;\n  margin-left: auto;\n  position: fixed;\n  text-align: center;\n  background: #fff;\n  padding-top: 14px;\n  top: 0;\n}\n\n.messBtn button {\n  color: #acacac;\n  background: #dbdbdb;\n  height: 45px;\n  width: 115px;\n  font-size: 20px;\n  outline: none;\n}\n\n.messBtn .nearby {\n  border-top-left-radius: 5px;\n  border-bottom-left-radius: 5px;\n  box-shadow: 0 0 10px 0.5px #b5afb5;\n}\n\n.messBtn .private {\n  border-top-right-radius: 5px;\n  border-bottom-right-radius: 5px;\n  box-shadow: 0 0 10px 0.5px #b5afb5;\n}\n\n.messBtn .activated1 {\n  background: #ababab;\n  color: #fff;\n}\n\n.messBtn .activated2 {\n  background: #ababab;\n  color: #fff;\n}\n\n.paddingTop {\n  padding-top: 60px;\n}\n\n.message .textMess {\n  font-weight: bold;\n  font-family: sans-serif;\n  line-height: 25px;\n  height: 50px;\n  overflow: hidden;\n  margin-top: 12px;\n  color: #12273d;\n  font-size: 17px;\n  border-bottom: 2px solid #f2f3f8;\n  margin-left: 4px;\n}\n\n.message .fromMessage {\n  width: 60%;\n  display: inline-block;\n}\n\n.message .fromMessage img {\n  width: 50px;\n  border-radius: 100%;\n  vertical-align: middle;\n}\n\n.message .fromMessage p {\n  display: inline-block;\n  margin: 0;\n  margin-left: 10px;\n  color: #6b798b;\n  font-size: 15px;\n  font-family: sans-serif;\n  letter-spacing: 0.5px;\n}\n\n.message .dateMessage {\n  width: 40%;\n  display: inline-block;\n  text-align: right;\n}\n\n.message .dateMessage .dateMess {\n  color: #6b798b;\n  font-size: 15px;\n  font-family: sans-serif;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9oYXJpL0RvY3VtZW50cy9wcm9qZWN0cy9wb3B3b3JrLWNhcGFjaXRvci9zcmMvYXBwL3BhZ2VzL21lc3NhZ2UvbWVzc2FnZS5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL21lc3NhZ2UvbWVzc2FnZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDRSw2QkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FDREY7O0FESUE7RUFDRSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUNERjs7QURHQTtFQUNFLG9CQUFBO0VBQ0EsUUFBQTtFQUNBLE9BQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLE1BQUE7QUNBRjs7QURDRTtFQUNFLGNBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGFBQUE7QUNDSjs7QURDRTtFQUNFLDJCQUFBO0VBQ0EsOEJBQUE7RUFHQSxrQ0FBQTtBQ0NKOztBRENFO0VBQ0UsNEJBQUE7RUFDQSwrQkFBQTtFQUdBLGtDQUFBO0FDQ0o7O0FEQ0U7RUFDRSxtQkFBQTtFQUNBLFdBQUE7QUNDSjs7QURDRTtFQUNFLG1CQUFBO0VBQ0EsV0FBQTtBQ0NKOztBREVFO0VBQ0UsaUJBQUE7QUNDSjs7QURFRTtFQUNFLGlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxnQ0FBQTtFQUNBLGdCQUFBO0FDQ0o7O0FEQ0U7RUFDRSxVQUFBO0VBQ0EscUJBQUE7QUNDSjs7QURBSTtFQUNFLFdBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0FDRU47O0FEQUk7RUFDRSxxQkFBQTtFQUNBLFNBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7RUFDQSxxQkFBQTtBQ0VOOztBRENFO0VBQ0UsVUFBQTtFQUNBLHFCQUFBO0VBQ0EsaUJBQUE7QUNDSjs7QURBSTtFQUNFLGNBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7QUNFTiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL21lc3NhZ2UvbWVzc2FnZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcblxuLm15Q2xhc3Mge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBsaWdodHllbGxvdzsgXG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi5hZGRDaGFubmVse1xuICBmbG9hdDogcmlnaHQ7XG4gIGZvbnQtc2l6ZTogMzJweDtcbiAgY29sb3I6ICMxMjQxNmE7XG59XG4ubWVzc0J0bntcbiAgcGFkZGluZy1ib3R0b206IDE0cHg7XG4gIHJpZ2h0OiAwO1xuICBsZWZ0OiAwO1xuICBtYXJnaW4tcmlnaHQ6IGF1dG87XG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgcGFkZGluZy10b3A6IDE0cHg7XG4gIHRvcDogMDtcbiAgYnV0dG9ue1xuICAgIGNvbG9yOiAjYWNhY2FjO1xuICAgIGJhY2tncm91bmQ6ICNkYmRiZGI7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIHdpZHRoOiAxMTVweDtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgb3V0bGluZTogbm9uZTtcbiAgfVxuICAubmVhcmJ5e1xuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDVweDtcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA1cHg7XG4gICAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDAgMTBweCAwLjVweCByZ2JhKDE4MSwxNzUsMTgxLDEpO1xuICAgIC1tb3otYm94LXNoYWRvdzogMCAwIDEwcHggMC41cHggcmdiYSgxODEsMTc1LDE4MSwxKTtcbiAgICBib3gtc2hhZG93OiAwIDAgMTBweCAwLjVweCByZ2JhKDE4MSwxNzUsMTgxLDEpO1xuICB9XG4gIC5wcml2YXRle1xuICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiA1cHg7XG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDVweDtcbiAgICAtd2Via2l0LWJveC1zaGFkb3c6IDAgMCAxMHB4IDAuNXB4IHJnYmEoMTgxLDE3NSwxODEsMSk7XG4gICAgLW1vei1ib3gtc2hhZG93OiAwIDAgMTBweCAwLjVweCByZ2JhKDE4MSwxNzUsMTgxLDEpO1xuICAgIGJveC1zaGFkb3c6IDAgMCAxMHB4IDAuNXB4IHJnYmEoMTgxLDE3NSwxODEsMSk7XG4gIH1cbiAgLmFjdGl2YXRlZDF7XG4gICAgYmFja2dyb3VuZDogcmdiYSgxNzEsMTcxLDE3MSwxKTtcbiAgICBjb2xvcjogI2ZmZjtcbiAgfVxuICAuYWN0aXZhdGVkMntcbiAgICBiYWNrZ3JvdW5kOiByZ2JhKDE3MSwxNzEsMTcxLDEpO1xuICAgIGNvbG9yOiAjZmZmO1xuICB9XG59XG4gIC5wYWRkaW5nVG9we1xuICAgIHBhZGRpbmctdG9wOiA2MHB4O1xuICB9XG4ubWVzc2FnZXtcbiAgLnRleHRNZXNze1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xuICAgIGxpbmUtaGVpZ2h0OiAyNXB4O1xuICAgIGhlaWdodDogNTBweDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIG1hcmdpbi10b3A6IDEycHg7XG4gICAgY29sb3I6ICMxMjI3M2Q7XG4gICAgZm9udC1zaXplOiAxN3B4O1xuICAgIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjZjJmM2Y4O1xuICAgIG1hcmdpbi1sZWZ0OiA0cHg7XG4gIH1cbiAgLmZyb21NZXNzYWdle1xuICAgIHdpZHRoOiA2MCU7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIGltZ3tcbiAgICAgIHdpZHRoOiA1MHB4O1xuICAgICAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gICAgfVxuICAgIHB7XG4gICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICBtYXJnaW46IDA7XG4gICAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICAgIGNvbG9yOiAjNmI3OThiO1xuICAgICAgZm9udC1zaXplOiAxNXB4O1xuICAgICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG4gICAgICBsZXR0ZXItc3BhY2luZzogMC41cHg7XG4gICAgfVxuICB9XG4gIC5kYXRlTWVzc2FnZXtcbiAgICB3aWR0aDogNDAlO1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICAuZGF0ZU1lc3N7XG4gICAgICBjb2xvcjogIzZiNzk4YjtcbiAgICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICAgIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xuICAgIH1cbiAgfVxufVxuIiwiLm15Q2xhc3Mge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBsaWdodHllbGxvdztcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMTAwJTtcbn1cblxuLmFkZENoYW5uZWwge1xuICBmbG9hdDogcmlnaHQ7XG4gIGZvbnQtc2l6ZTogMzJweDtcbiAgY29sb3I6ICMxMjQxNmE7XG59XG5cbi5tZXNzQnRuIHtcbiAgcGFkZGluZy1ib3R0b206IDE0cHg7XG4gIHJpZ2h0OiAwO1xuICBsZWZ0OiAwO1xuICBtYXJnaW4tcmlnaHQ6IGF1dG87XG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgcGFkZGluZy10b3A6IDE0cHg7XG4gIHRvcDogMDtcbn1cbi5tZXNzQnRuIGJ1dHRvbiB7XG4gIGNvbG9yOiAjYWNhY2FjO1xuICBiYWNrZ3JvdW5kOiAjZGJkYmRiO1xuICBoZWlnaHQ6IDQ1cHg7XG4gIHdpZHRoOiAxMTVweDtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBvdXRsaW5lOiBub25lO1xufVxuLm1lc3NCdG4gLm5lYXJieSB7XG4gIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDVweDtcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogNXB4O1xuICAtd2Via2l0LWJveC1zaGFkb3c6IDAgMCAxMHB4IDAuNXB4ICNiNWFmYjU7XG4gIC1tb3otYm94LXNoYWRvdzogMCAwIDEwcHggMC41cHggI2I1YWZiNTtcbiAgYm94LXNoYWRvdzogMCAwIDEwcHggMC41cHggI2I1YWZiNTtcbn1cbi5tZXNzQnRuIC5wcml2YXRlIHtcbiAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDVweDtcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDVweDtcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDAgMTBweCAwLjVweCAjYjVhZmI1O1xuICAtbW96LWJveC1zaGFkb3c6IDAgMCAxMHB4IDAuNXB4ICNiNWFmYjU7XG4gIGJveC1zaGFkb3c6IDAgMCAxMHB4IDAuNXB4ICNiNWFmYjU7XG59XG4ubWVzc0J0biAuYWN0aXZhdGVkMSB7XG4gIGJhY2tncm91bmQ6ICNhYmFiYWI7XG4gIGNvbG9yOiAjZmZmO1xufVxuLm1lc3NCdG4gLmFjdGl2YXRlZDIge1xuICBiYWNrZ3JvdW5kOiAjYWJhYmFiO1xuICBjb2xvcjogI2ZmZjtcbn1cblxuLnBhZGRpbmdUb3Age1xuICBwYWRkaW5nLXRvcDogNjBweDtcbn1cblxuLm1lc3NhZ2UgLnRleHRNZXNzIHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xuICBsaW5lLWhlaWdodDogMjVweDtcbiAgaGVpZ2h0OiA1MHB4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBtYXJnaW4tdG9wOiAxMnB4O1xuICBjb2xvcjogIzEyMjczZDtcbiAgZm9udC1zaXplOiAxN3B4O1xuICBib3JkZXItYm90dG9tOiAycHggc29saWQgI2YyZjNmODtcbiAgbWFyZ2luLWxlZnQ6IDRweDtcbn1cbi5tZXNzYWdlIC5mcm9tTWVzc2FnZSB7XG4gIHdpZHRoOiA2MCU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbn1cbi5tZXNzYWdlIC5mcm9tTWVzc2FnZSBpbWcge1xuICB3aWR0aDogNTBweDtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbn1cbi5tZXNzYWdlIC5mcm9tTWVzc2FnZSBwIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBtYXJnaW46IDA7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBjb2xvcjogIzZiNzk4YjtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcbiAgbGV0dGVyLXNwYWNpbmc6IDAuNXB4O1xufVxuLm1lc3NhZ2UgLmRhdGVNZXNzYWdlIHtcbiAgd2lkdGg6IDQwJTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB0ZXh0LWFsaWduOiByaWdodDtcbn1cbi5tZXNzYWdlIC5kYXRlTWVzc2FnZSAuZGF0ZU1lc3Mge1xuICBjb2xvcjogIzZiNzk4YjtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/message/message.page.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/message/message.page.ts ***!
  \***********************************************/
/*! exports provided: MessagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessagePage", function() { return MessagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../services/auth.service */ "./src/services/auth.service.ts");
/* harmony import */ var _utils_local_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../utils/local-storage */ "./src/utils/local-storage.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");







var MessagePage = /** @class */ (function () {
    function MessagePage(router, authService, events, activatedRoute) {
        this.router = router;
        this.authService = authService;
        this.events = events;
        this.activatedRoute = activatedRoute;
        this.buttonActiveNearby = true;
        this.messages = [];
        this.public = false;
        this.private = false;
    }
    MessagePage.prototype.ngOnInit = function () {
        this.public = true;
        this.private = false;
        this.currentUserId = Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_4__["getFromLocalStorage"])('VB_USER').user.id;
        this.getNearby('public');
        this.events.subscribe("public_message_posted", function () {
            this.getNearby('public');
        }.bind(this));
    };
    MessagePage.prototype.ionViewDidEnter = function () {
        if (this.activatedRoute.snapshot.paramMap.get('msgtype') == "public") {
            this.goToPublicMess(this.activatedRoute.snapshot.paramMap.get('msgid'));
        }
        else if (this.activatedRoute.snapshot.paramMap.get('msgtype') == "private") {
            this.goToPrivateMess(this.activatedRoute.snapshot.paramMap.get('msgid'));
        }
    };
    MessagePage.prototype.getNearby = function (type) {
        var _this = this;
        this.buttonActiveNearby = type === 'public';
        this.buttonActivePrivate = type === 'private';
        if (type === 'public') {
            this.public = true;
            this.private = false;
            this.authService.getChannels(type).subscribe(function (publicChannels) {
                _this.messages = publicChannels;
            });
        }
        else if (type === 'private') {
            this.public = false;
            this.private = true;
            this.authService.getChannels(type).subscribe(function (privateChannels) {
                _this.messages = privateChannels;
            });
            // this.authService.getPrivateMess().subscribe((messPrivate: any) => {
            //     this.messages = messPrivate;
            //     for (const message of this.messages) {
            //         if (message.fromuser === this.currentUserId) {
            //             this.userId = message.touser;
            //         } else {
            //             this.userId = message.fromuser;
            //         }
            //     }
            // });
        }
    };
    MessagePage.prototype.goToPublicMess = function (mess, add) {
        if (add === void 0) { add = false; }
        this.router.navigate(['chat/' + mess.id, { data: JSON.stringify(mess), add: add }]).then();
    };
    MessagePage.prototype.addMessage = function (event, mess) {
        event.stopPropagation();
        this.goToPublicMess(mess, true);
    };
    MessagePage.prototype.goToPrivateMess = function (id) {
        this.router.navigate(['private-chat/' + id]).then();
    };
    MessagePage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Events"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] }
    ]; };
    MessagePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-message',
            template: __webpack_require__(/*! raw-loader!./message.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/message/message.page.html"),
            styles: [__webpack_require__(/*! ./message.page.scss */ "./src/app/pages/message/message.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Events"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], MessagePage);
    return MessagePage;
}());



/***/ })

}]);
//# sourceMappingURL=message-message-module-es5.js.map