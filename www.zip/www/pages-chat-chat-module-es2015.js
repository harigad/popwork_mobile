(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-chat-chat-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/chat/chat.page.html":
/*!*********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/chat/chat.page.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n          <ion-back-button></ion-back-button>\n        </ion-buttons>\n      </ion-toolbar>\n</ion-header>\n\n<ion-content color=\"light\" >\n    <div (click)=\"goToPublicMess(mess.id)\" style=\"background-color:#fff;margin:10px;border-radius:4px;font-size:0.9em;padding:10px;display:flex;flex-direction: row ;\"  > \n        <span style=\"flex: none;\" >\n        <img [src]=\"mess.photo\" style=\"margin-right:5px;border-radius:50px;overflow:hidden;width:50px;height:50px;\" > \n      </span>  \n          <div style=\"flex:1\">\n            <div style=\"display:flex;flex-direction: row ;\" >\n              <span style=\"flex:1;font-size:0.8em;color:#666;\">\n                  {{mess.fullname}}---\n              </span>\n              <span style=\"flex: none; align-self:flex-end; font-size:0.8em;color:#666;\" >{{ mess.created | amTimeAgo }}</span>\n            </div> \n            <div style=\"color:#666;\" >\n                <span style=\"font-size:0.8em;color:#ff0077\" >Mudsmith Coffee House</span>\n            <div style=\"color:#000;font-size:0.8em;\">{{mess.title}}</div>\n\n            <div style=\"display:flex;flex-direction: row;\" >\n               \n                <span style=\"padding-top:5px;padding-bottom:5px;vertical-align: top;flex: none; align-self:flex-end; font-size:0.8em;color:#666;\" >235 comments</span>\n              </div> \n         \n            </div>\n\n\n          </div>\n      </div>\n\n\n  <div class=\"chat\" *ngFor=\"let message of messages\" style=\"padding:10px;font-size:0.8em;\">\n    <div [ngClass]=\"currentUserId === message.user ? 'currentUser' : 'channelUser'\">\n      <div *ngIf=\"currentUserId !== message.user\" class=\"fromUser\">\n        <img  src=\"{{ message.photo || './assets/imgs/no_avatar.png'}}\">\n      </div>\n      <div class=\"fromMess\">\n        <p>{{ message.message }}</p>\n      </div>\n      <div class=\"clearfix\"></div>\n    </div>\n  </div>\n</ion-content>\n<ion-footer>\n  <ion-toolbar>\n    <form class=\"messageForm\" [formGroup]=\"sendMessage\">\n    <div class=\"inputMess\">\n      <ion-input id=\"inputValue\" class=\"textMess\" placeholder=\"reply\" formControlName=\"message\" type=\"text\"></ion-input>\n    </div>\n    <div class=\"sendMess\">\n      <button (click)=\"send(sendMessage.value)\" ion-button><ion-icon name=\"arrow-dropright-circle\"></ion-icon></button>\n    </div>\n    <div class=\"clearfix\"></div>\n    </form>\n  </ion-toolbar>\n</ion-footer>\n"

/***/ }),

/***/ "./src/app/pages/chat/chat.module.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/chat/chat.module.ts ***!
  \*******************************************/
/*! exports provided: ChatPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChatPageModule", function() { return ChatPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var ngx_moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-moment */ "./node_modules/ngx-moment/fesm2015/ngx-moment.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _chat_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./chat.page */ "./src/app/pages/chat/chat.page.ts");








const routes = [
    {
        path: '',
        component: _chat_page__WEBPACK_IMPORTED_MODULE_7__["ChatPage"]
    }
];
let ChatPageModule = class ChatPageModule {
};
ChatPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            ngx_moment__WEBPACK_IMPORTED_MODULE_5__["MomentModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_chat_page__WEBPACK_IMPORTED_MODULE_7__["ChatPage"]]
    })
], ChatPageModule);



/***/ }),

/***/ "./src/app/pages/chat/chat.page.scss":
/*!*******************************************!*\
  !*** ./src/app/pages/chat/chat.page.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".clearfix {\n  clear: both;\n}\n\n.inline {\n  display: inline-block;\n  text-align: center;\n}\n\n.arrowBack {\n  width: 12%;\n}\n\n.arrowBack button {\n  background: #b9b9b9;\n  border-radius: 100%;\n  width: 32px;\n  height: 32px;\n  outline: none;\n}\n\n.arrowBack button ion-icon {\n  color: #fff;\n  font-size: 20px;\n}\n\n.autorChat {\n  width: 76%;\n}\n\n.autorChat h4 {\n  margin-bottom: 4px;\n  color: #acacac;\n  text-transform: uppercase;\n}\n\n.arrowMore {\n  width: 12%;\n}\n\n.arrowMore button {\n  background: none;\n}\n\n.arrowMore button ion-icon {\n  font-size: 34px;\n  color: #9e9999;\n}\n\n.placeInfo {\n  text-align: center;\n}\n\n.placeInfo span {\n  color: #2563ef;\n  letter-spacing: 2px;\n}\n\n.fromUser {\n  width: 17%;\n  float: left;\n}\n\n.fromUser img {\n  border-radius: 100%;\n  width: 50px;\n  height: 50px;\n}\n\n.chat {\n  display: inline-block;\n  width: 100%;\n}\n\n.chat .fromMess {\n  width: 83%;\n  float: left;\n}\n\n.chat .fromMess p {\n  width: 230px;\n  background: #f5f5f5;\n  border-bottom-left-radius: 20px;\n  border-top-right-radius: 20px;\n  border-bottom-right-radius: 20px;\n  padding: 15px 20px;\n  margin-bottom: 0px;\n}\n\n.chat .currentUser {\n  float: right;\n}\n\n.chat .currentUser .fromMess p {\n  width: 230px;\n  background: #746bbd;\n  border-bottom-left-radius: 20px;\n  border-top-right-radius: 0;\n  border-bottom-right-radius: 20px;\n  border-top-left-radius: 20px;\n  padding: 15px 20px;\n  color: #fff;\n}\n\n.inputMess {\n  width: 80%;\n  float: left;\n}\n\n.inputMess .textMess {\n  font-size: 15px;\n}\n\n.sendMess {\n  width: 20%;\n  float: left;\n}\n\n.sendMess button {\n  background: none;\n  outline: none;\n}\n\n.sendMess button ion-icon {\n  font-size: 44px;\n  color: #3a95ff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9oYXJpL0RvY3VtZW50cy9wcm9qZWN0cy9wb3B3b3JrLWNhcGFjaXRvci9zcmMvYXBwL3BhZ2VzL2NoYXQvY2hhdC5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2NoYXQvY2hhdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFBO0FDQ0Y7O0FEQ0E7RUFDRSxxQkFBQTtFQUNBLGtCQUFBO0FDRUY7O0FEQUE7RUFDRSxVQUFBO0FDR0Y7O0FERkU7RUFDRSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0FDSUo7O0FESEk7RUFDRSxXQUFBO0VBQ0EsZUFBQTtBQ0tOOztBRERBO0VBQ0UsVUFBQTtBQ0lGOztBREhFO0VBQ0Usa0JBQUE7RUFDQSxjQUFBO0VBQ0EseUJBQUE7QUNLSjs7QURGQTtFQUNFLFVBQUE7QUNLRjs7QURKRTtFQUNFLGdCQUFBO0FDTUo7O0FETEk7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQ09OOztBREhBO0VBQ0Usa0JBQUE7QUNNRjs7QURMRTtFQUNFLGNBQUE7RUFDQSxtQkFBQTtBQ09KOztBREpBO0VBQ0UsVUFBQTtFQUNBLFdBQUE7QUNPRjs7QURORTtFQUNFLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNRSjs7QURMQTtFQUNFLHFCQUFBO0VBQ0EsV0FBQTtBQ1FGOztBRFBFO0VBQ0UsVUFBQTtFQUNBLFdBQUE7QUNTSjs7QURSSTtFQUNFLFlBQUE7RUFDQSxtQkFBQTtFQUNBLCtCQUFBO0VBQ0EsNkJBQUE7RUFDQSxnQ0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUNVTjs7QURQRTtFQUNFLFlBQUE7QUNTSjs7QURQTTtFQUNFLFlBQUE7RUFDQSxtQkFBQTtFQUNBLCtCQUFBO0VBQ0EsMEJBQUE7RUFDQSxnQ0FBQTtFQUNBLDRCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0FDU1I7O0FESEE7RUFDRSxVQUFBO0VBQ0EsV0FBQTtBQ01GOztBRExFO0VBQ0UsZUFBQTtBQ09KOztBREpBO0VBQ0UsVUFBQTtFQUNBLFdBQUE7QUNPRjs7QURORTtFQUNFLGdCQUFBO0VBQ0EsYUFBQTtBQ1FKOztBRFBJO0VBQ0UsZUFBQTtFQUNBLGNBQUE7QUNTTiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2NoYXQvY2hhdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2xlYXJmaXh7XG4gIGNsZWFyOiBib3RoO1xufVxuLmlubGluZXtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4uYXJyb3dCYWNre1xuICB3aWR0aDogMTIlO1xuICBidXR0b257XG4gICAgYmFja2dyb3VuZDogI2I5YjliOTtcbiAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICAgIHdpZHRoOiAzMnB4O1xuICAgIGhlaWdodDogMzJweDtcbiAgICBvdXRsaW5lOiBub25lO1xuICAgIGlvbi1pY29ue1xuICAgICAgY29sb3I6ICNmZmY7XG4gICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgfVxuICB9XG59XG4uYXV0b3JDaGF0e1xuICB3aWR0aDogNzYlO1xuICBoNHtcbiAgICBtYXJnaW4tYm90dG9tOiA0cHg7XG4gICAgY29sb3I6ICNhY2FjYWM7XG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgfVxufVxuLmFycm93TW9yZXtcbiAgd2lkdGg6IDEyJTtcbiAgYnV0dG9ue1xuICAgIGJhY2tncm91bmQ6IG5vbmU7XG4gICAgaW9uLWljb257XG4gICAgICBmb250LXNpemU6IDM0cHg7XG4gICAgICBjb2xvcjogIzllOTk5OTtcbiAgICB9XG4gIH1cbn1cbi5wbGFjZUluZm97XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgc3BhbntcbiAgICBjb2xvcjogIzI1NjNlZjtcbiAgICBsZXR0ZXItc3BhY2luZzogMnB4O1xuICB9XG59XG4uZnJvbVVzZXJ7XG4gIHdpZHRoOiAxNyU7XG4gIGZsb2F0OiBsZWZ0O1xuICBpbWd7XG4gICAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgICB3aWR0aDogNTBweDtcbiAgICBoZWlnaHQ6IDUwcHg7XG4gIH1cbn1cbi5jaGF0e1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHdpZHRoOiAxMDAlO1xuICAuZnJvbU1lc3N7XG4gICAgd2lkdGg6IDgzJTtcbiAgICBmbG9hdDogbGVmdDtcbiAgICBwe1xuICAgICAgd2lkdGg6IDIzMHB4O1xuICAgICAgYmFja2dyb3VuZDogI2Y1ZjVmNTtcbiAgICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDIwcHg7XG4gICAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMjBweDtcbiAgICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xuICAgICAgcGFkZGluZzogMTVweCAyMHB4O1xuICAgICAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICAgIH1cbiAgfVxuICAuY3VycmVudFVzZXJ7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICAgIC5mcm9tTWVzc3tcbiAgICAgIHB7XG4gICAgICAgIHdpZHRoOiAyMzBweDtcbiAgICAgICAgYmFja2dyb3VuZDogIzc0NmJiZDtcbiAgICAgICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcbiAgICAgICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDA7XG4gICAgICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xuICAgICAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAyMHB4O1xuICAgICAgICBwYWRkaW5nOiAxNXB4IDIwcHg7XG4gICAgICAgIGNvbG9yOiAjZmZmO1xuXG4gICAgICB9XG4gICAgfVxuICB9XG59XG4uaW5wdXRNZXNze1xuICB3aWR0aDogODAlO1xuICBmbG9hdDogbGVmdDtcbiAgLnRleHRNZXNze1xuICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgfVxufVxuLnNlbmRNZXNze1xuICB3aWR0aDogMjAlO1xuICBmbG9hdDogbGVmdDtcbiAgYnV0dG9ue1xuICAgIGJhY2tncm91bmQ6IG5vbmU7XG4gICAgb3V0bGluZTogbm9uZTtcbiAgICBpb24taWNvbntcbiAgICAgIGZvbnQtc2l6ZTogNDRweDtcbiAgICAgIGNvbG9yOiAjM2E5NWZmO1xuICAgIH1cbiAgfVxufVxuIiwiLmNsZWFyZml4IHtcbiAgY2xlYXI6IGJvdGg7XG59XG5cbi5pbmxpbmUge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmFycm93QmFjayB7XG4gIHdpZHRoOiAxMiU7XG59XG4uYXJyb3dCYWNrIGJ1dHRvbiB7XG4gIGJhY2tncm91bmQ6ICNiOWI5Yjk7XG4gIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gIHdpZHRoOiAzMnB4O1xuICBoZWlnaHQ6IDMycHg7XG4gIG91dGxpbmU6IG5vbmU7XG59XG4uYXJyb3dCYWNrIGJ1dHRvbiBpb24taWNvbiB7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXNpemU6IDIwcHg7XG59XG5cbi5hdXRvckNoYXQge1xuICB3aWR0aDogNzYlO1xufVxuLmF1dG9yQ2hhdCBoNCB7XG4gIG1hcmdpbi1ib3R0b206IDRweDtcbiAgY29sb3I6ICNhY2FjYWM7XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG59XG5cbi5hcnJvd01vcmUge1xuICB3aWR0aDogMTIlO1xufVxuLmFycm93TW9yZSBidXR0b24ge1xuICBiYWNrZ3JvdW5kOiBub25lO1xufVxuLmFycm93TW9yZSBidXR0b24gaW9uLWljb24ge1xuICBmb250LXNpemU6IDM0cHg7XG4gIGNvbG9yOiAjOWU5OTk5O1xufVxuXG4ucGxhY2VJbmZvIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLnBsYWNlSW5mbyBzcGFuIHtcbiAgY29sb3I6ICMyNTYzZWY7XG4gIGxldHRlci1zcGFjaW5nOiAycHg7XG59XG5cbi5mcm9tVXNlciB7XG4gIHdpZHRoOiAxNyU7XG4gIGZsb2F0OiBsZWZ0O1xufVxuLmZyb21Vc2VyIGltZyB7XG4gIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gIHdpZHRoOiA1MHB4O1xuICBoZWlnaHQ6IDUwcHg7XG59XG5cbi5jaGF0IHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB3aWR0aDogMTAwJTtcbn1cbi5jaGF0IC5mcm9tTWVzcyB7XG4gIHdpZHRoOiA4MyU7XG4gIGZsb2F0OiBsZWZ0O1xufVxuLmNoYXQgLmZyb21NZXNzIHAge1xuICB3aWR0aDogMjMwcHg7XG4gIGJhY2tncm91bmQ6ICNmNWY1ZjU7XG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDIwcHg7XG4gIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAyMHB4O1xuICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcbiAgcGFkZGluZzogMTVweCAyMHB4O1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG59XG4uY2hhdCAuY3VycmVudFVzZXIge1xuICBmbG9hdDogcmlnaHQ7XG59XG4uY2hhdCAuY3VycmVudFVzZXIgLmZyb21NZXNzIHAge1xuICB3aWR0aDogMjMwcHg7XG4gIGJhY2tncm91bmQ6ICM3NDZiYmQ7XG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDIwcHg7XG4gIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAwO1xuICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcbiAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMjBweDtcbiAgcGFkZGluZzogMTVweCAyMHB4O1xuICBjb2xvcjogI2ZmZjtcbn1cblxuLmlucHV0TWVzcyB7XG4gIHdpZHRoOiA4MCU7XG4gIGZsb2F0OiBsZWZ0O1xufVxuLmlucHV0TWVzcyAudGV4dE1lc3Mge1xuICBmb250LXNpemU6IDE1cHg7XG59XG5cbi5zZW5kTWVzcyB7XG4gIHdpZHRoOiAyMCU7XG4gIGZsb2F0OiBsZWZ0O1xufVxuLnNlbmRNZXNzIGJ1dHRvbiB7XG4gIGJhY2tncm91bmQ6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG59XG4uc2VuZE1lc3MgYnV0dG9uIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiA0NHB4O1xuICBjb2xvcjogIzNhOTVmZjtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/chat/chat.page.ts":
/*!*****************************************!*\
  !*** ./src/app/pages/chat/chat.page.ts ***!
  \*****************************************/
/*! exports provided: ChatPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChatPage", function() { return ChatPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../services/auth.service */ "./src/services/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _utils_local_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../utils/local-storage */ "./src/utils/local-storage.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");







let ChatPage = class ChatPage {
    constructor(authService, activeRouter, router, formBuilder, navCtrl) {
        this.authService = authService;
        this.activeRouter = activeRouter;
        this.router = router;
        this.formBuilder = formBuilder;
        this.navCtrl = navCtrl;
        this.sendMessage = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({});
        this.messages = [];
        this.mess = {};
        this.error = false;
        this.status = false;
        this.textMess = [];
        this.sendMessage = this.formBuilder.group({
            message: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
        });
    }
    ionViewDidEnter() {
        this.currentUserId = Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_5__["getFromLocalStorage"])('VB_USER').user.id;
        this.activeRouter.params.subscribe(params => {
            this.mess = JSON.parse(params.data);
            const data = params.id;
            this.channelId = params.id;
            this.authService.getMessagesById(data).subscribe((mess) => {
                this.channelcreatedUser = mess[0].channel_created_user;
                if (mess[0].message) {
                    this.messages = mess;
                }
                console.log(mess);
            });
        });
    }
    backToMessage() {
        this.navCtrl.back();
    }
    send(message) {
        if (this.sendMessage.valid) {
            const data = {
                user: this.currentUserId,
                message: message.message,
                channel: this.channelId,
                popwork: 0
            };
            this.authService.sendMessage(data).subscribe((mess) => {
                this.textMess = mess;
                if (mess.insertId) {
                    this.messages.push({
                        message: message.message,
                        channel: this.channelId,
                        user: this.currentUserId
                    });
                }
                console.log(this.textMess);
                this.sendMessage.get('message').setValue('');
            });
        }
    }
};
ChatPage.ctorParameters = () => [
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] }
];
ChatPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-chat',
        template: __webpack_require__(/*! raw-loader!./chat.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/chat/chat.page.html"),
        styles: [__webpack_require__(/*! ./chat.page.scss */ "./src/app/pages/chat/chat.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"]])
], ChatPage);



/***/ })

}]);
//# sourceMappingURL=pages-chat-chat-module-es2015.js.map