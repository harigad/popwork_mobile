(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-main-main-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/main/main.page.html":
/*!*********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/main/main.page.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-tabs>\n    <div class=\"footer-tabs\">\n        <ion-tab-bar slot=\"bottom\">\n           <!---- <ion-tab-button tab=\"message\">\n                <ion-icon class=\"qr\" name=\"chatbubbles\"></ion-icon>\n                <ion-label>pop workers</ion-label>\n            </ion-tab-button>-->\n\n            <ion-tab-button tab=\"map\">\n                <ion-icon class=\"location-color\" name=\"cafe\"></ion-icon>\n               <ion-label>popworks</ion-label>\n            </ion-tab-button>\n              \n            <ion-tab-button tab=\"settings\">\n                <ion-icon class=\"sett-icon\" name=\"md-settings\"></ion-icon>\n                <ion-label>me & myself</ion-label>\n            </ion-tab-button>\n        </ion-tab-bar>\n    </div>\n</ion-tabs>\n"

/***/ }),

/***/ "./src/app/pages/main/main.module.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/main/main.module.ts ***!
  \*******************************************/
/*! exports provided: MainPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainPageModule", function() { return MainPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _main_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./main.page */ "./src/app/pages/main/main.page.ts");
/* harmony import */ var ngx_moment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-moment */ "./node_modules/ngx-moment/fesm5/ngx-moment.js");








var routes = [
    {
        path: '',
        component: _main_page__WEBPACK_IMPORTED_MODULE_6__["MainPage"],
        children: [
            {
                path: 'message',
                children: [
                    {
                        path: '',
                        loadChildren: '../message/message.module#MessagePageModule'
                    }
                ]
            },
            {
                path: 'message/:msgtype/:msgid',
                children: [
                    {
                        path: '',
                        loadChildren: '../message/message.module#MessagePageModule'
                    }
                ]
            },
            {
                path: 'map',
                children: [
                    {
                        path: '',
                        loadChildren: '../map/map.module#MapPageModule'
                    }
                ]
            },
            {
                path: 'settings',
                children: [
                    {
                        path: '',
                        loadChildren: '../settings/settings.module#SettingsPageModule'
                    }
                ]
            },
            {
                path: '',
                redirectTo: '/main/map',
                pathMatch: 'full'
            }
        ]
    },
];
var MainPageModule = /** @class */ (function () {
    function MainPageModule() {
    }
    MainPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                ngx_moment__WEBPACK_IMPORTED_MODULE_7__["MomentModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_main_page__WEBPACK_IMPORTED_MODULE_6__["MainPage"]]
        })
    ], MainPageModule);
    return MainPageModule;
}());



/***/ }),

/***/ "./src/app/pages/main/main.page.scss":
/*!*******************************************!*\
  !*** ./src/app/pages/main/main.page.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".footer-tabs {\n  text-align: center;\n}\n.footer-tabs .settings, .footer-tabs .qr-code, .footer-tabs .location {\n  width: 30%;\n  display: inline-block;\n}\n.footer-tabs .settings button, .footer-tabs .qr-code button, .footer-tabs .location button {\n  background: none;\n  outline: none;\n}\n.footer-tabs .settings button .location-color, .footer-tabs .qr-code button .location-color, .footer-tabs .location button .location-color {\n  color: #ff0046;\n  font-size: 30px;\n}\n.footer-tabs .settings button .sett-icon, .footer-tabs .qr-code button .sett-icon, .footer-tabs .location button .sett-icon {\n  color: grey;\n  font-size: 30px;\n}\n.footer-tabs .settings button .qr, .footer-tabs .qr-code button .qr, .footer-tabs .location button .qr {\n  font-size: 30px;\n  color: grey;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9oYXJpL0RvY3VtZW50cy9wcm9qZWN0cy9wb3B3b3JrLWNhcGFjaXRvci9zcmMvYXBwL3BhZ2VzL21haW4vbWFpbi5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL21haW4vbWFpbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBQTtBQ0NGO0FEQUU7RUFDRSxVQUFBO0VBQ0EscUJBQUE7QUNFSjtBRERJO0VBQ0UsZ0JBQUE7RUFDQSxhQUFBO0FDR047QURGTTtFQUNFLGNBQUE7RUFDQSxlQUFBO0FDSVI7QURGTTtFQUNFLFdBQUE7RUFDQSxlQUFBO0FDSVI7QURGTTtFQUNFLGVBQUE7RUFDQSxXQUFBO0FDSVIiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9tYWluL21haW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmZvb3Rlci10YWJze1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIC5zZXR0aW5ncywgLnFyLWNvZGUsLmxvY2F0aW9uIHtcbiAgICB3aWR0aDogMzAlO1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICBidXR0b257XG4gICAgICBiYWNrZ3JvdW5kOiBub25lO1xuICAgICAgb3V0bGluZTogbm9uZTtcbiAgICAgIC5sb2NhdGlvbi1jb2xvcntcbiAgICAgICAgY29sb3I6ICNmZjAwNDY7XG4gICAgICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICAgIH1cbiAgICAgIC5zZXR0LWljb257XG4gICAgICAgIGNvbG9yOiBncmV5O1xuICAgICAgICBmb250LXNpemU6IDMwcHg7XG4gICAgICB9XG4gICAgICAucXJ7XG4gICAgICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICAgICAgY29sb3I6IGdyZXk7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iLCIuZm9vdGVyLXRhYnMge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4uZm9vdGVyLXRhYnMgLnNldHRpbmdzLCAuZm9vdGVyLXRhYnMgLnFyLWNvZGUsIC5mb290ZXItdGFicyAubG9jYXRpb24ge1xuICB3aWR0aDogMzAlO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG59XG4uZm9vdGVyLXRhYnMgLnNldHRpbmdzIGJ1dHRvbiwgLmZvb3Rlci10YWJzIC5xci1jb2RlIGJ1dHRvbiwgLmZvb3Rlci10YWJzIC5sb2NhdGlvbiBidXR0b24ge1xuICBiYWNrZ3JvdW5kOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xufVxuLmZvb3Rlci10YWJzIC5zZXR0aW5ncyBidXR0b24gLmxvY2F0aW9uLWNvbG9yLCAuZm9vdGVyLXRhYnMgLnFyLWNvZGUgYnV0dG9uIC5sb2NhdGlvbi1jb2xvciwgLmZvb3Rlci10YWJzIC5sb2NhdGlvbiBidXR0b24gLmxvY2F0aW9uLWNvbG9yIHtcbiAgY29sb3I6ICNmZjAwNDY7XG4gIGZvbnQtc2l6ZTogMzBweDtcbn1cbi5mb290ZXItdGFicyAuc2V0dGluZ3MgYnV0dG9uIC5zZXR0LWljb24sIC5mb290ZXItdGFicyAucXItY29kZSBidXR0b24gLnNldHQtaWNvbiwgLmZvb3Rlci10YWJzIC5sb2NhdGlvbiBidXR0b24gLnNldHQtaWNvbiB7XG4gIGNvbG9yOiBncmV5O1xuICBmb250LXNpemU6IDMwcHg7XG59XG4uZm9vdGVyLXRhYnMgLnNldHRpbmdzIGJ1dHRvbiAucXIsIC5mb290ZXItdGFicyAucXItY29kZSBidXR0b24gLnFyLCAuZm9vdGVyLXRhYnMgLmxvY2F0aW9uIGJ1dHRvbiAucXIge1xuICBmb250LXNpemU6IDMwcHg7XG4gIGNvbG9yOiBncmV5O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/main/main.page.ts":
/*!*****************************************!*\
  !*** ./src/app/pages/main/main.page.ts ***!
  \*****************************************/
/*! exports provided: MainPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainPage", function() { return MainPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../services/auth.service */ "./src/services/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var PushNotifications = _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["Plugins"].PushNotifications;
var Device = _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["Plugins"].Device;


var MainPage = /** @class */ (function () {
    function MainPage(authService, router) {
        this.authService = authService;
        this.router = router;
    }
    MainPage.prototype.ngOnInit = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var device;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, Device.getInfo()];
                    case 1:
                        device = _a.sent();
                        this.deviceInfo = {
                            apns: true,
                            pushToken: this.pushToken,
                            deviceid: device.uuid,
                            devicetype: device.platform,
                            devicemaker: device.manufacturer,
                            devicemodel: device.model,
                            meta: ''
                        };
                        this.pushSetup();
                        return [2 /*return*/];
                }
            });
        });
    };
    MainPage.prototype.ionViewDidEnter = function () {
    };
    MainPage.prototype.pushSetup = function () {
        var _this = this;
        PushNotifications.register();
        var options = {
            android: {},
            ios: {
                alert: 'true',
                badge: true,
                sound: 'false'
            },
        };
        PushNotifications.addListener('registrationError', function (error) {
            alert('Error on registration: ' + JSON.stringify(error));
        });
        PushNotifications.addListener('registration', function (token) {
            _this.pushToken = token;
            _this.deviceInfo.pushToken = token;
            _this.authService.setDeviceInfo(_this.deviceInfo).subscribe(function (info) {
                console.log(info);
            });
        });
        PushNotifications.addListener('pushNotificationReceived', function (notification) {
            alert('Push received: ' + JSON.stringify(notification));
        });
        // Method called when tapping on a notification
        PushNotifications.addListener('pushNotificationActionPerformed', function (notification) {
            alert('Push action performed: ' + JSON.stringify(notification));
        });
    };
    MainPage.ctorParameters = function () { return [
        { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
    ]; };
    MainPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-main',
            template: __webpack_require__(/*! raw-loader!./main.page.html */ "./node_modules/raw-loader/index.js!./src/app/pages/main/main.page.html"),
            styles: [__webpack_require__(/*! ./main.page.scss */ "./src/app/pages/main/main.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
    ], MainPage);
    return MainPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-main-main-module-es5.js.map